import { NextResponse } from 'next/server'
import { listRecords, createRecord, configFromRequest } from '@/lib/cloudflare'

export const dynamic = 'force-dynamic'

export async function GET(request: Request) {
  try {
    const cfg = configFromRequest(request)
    const records = await listRecords(cfg)
    return NextResponse.json({ records })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const cfg = configFromRequest(request)
    const body = await request.json()
    const { subdomain, type, content, proxied } = body ?? {}

    if (!subdomain || !type || !content) {
      return NextResponse.json(
        { error: 'subdomain, type, dan content wajib diisi.' },
        { status: 400 },
      )
    }

    const record = await createRecord(cfg, {
      subdomain,
      type,
      content,
      proxied: Boolean(proxied),
    })

    return NextResponse.json({ record })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
