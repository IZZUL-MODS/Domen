import { NextResponse } from 'next/server'
import { updateRecord, deleteRecord, configFromRequest } from '@/lib/cloudflare'

export const dynamic = 'force-dynamic'

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    const cfg = configFromRequest(request)
    const body = await request.json()
    const { subdomain, type, content, proxied } = body ?? {}

    if (!subdomain || !type || !content) {
      return NextResponse.json(
        { error: 'subdomain, type, dan content wajib diisi.' },
        { status: 400 },
      )
    }

    const record = await updateRecord(cfg, {
      id,
      subdomain,
      type,
      content,
      proxied: Boolean(proxied),
    })

    return NextResponse.json({ record })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params
    const cfg = configFromRequest(request)
    await deleteRecord(cfg, id)
    return NextResponse.json({ ok: true })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
