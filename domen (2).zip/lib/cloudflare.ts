// Server-only Cloudflare helper. Never import this from client components.

export const DEFAULT_ROOT_DOMAIN = 'izsubdo.my.id'

const API_BASE = 'https://api.cloudflare.com/client/v4'

export type CfConfig = {
  domain: string
  token?: string
  zoneId?: string
}

/** Build a config object from the request headers sent by the client. */
export function configFromRequest(request: Request): CfConfig {
  const h = request.headers
  return {
    domain: h.get('x-cf-domain')?.trim().toLowerCase() || DEFAULT_ROOT_DOMAIN,
    token: h.get('x-cf-token')?.trim() || undefined,
    zoneId: h.get('x-cf-zone')?.trim() || undefined,
  }
}

function resolveToken(cfg: CfConfig) {
  const token = cfg.token || process.env.CLOUDFLARE_API_TOKEN
  if (!token) {
    throw new Error(
      `Tidak ada API token untuk domain ${cfg.domain}. Tambahkan token lewat panel admin.`,
    )
  }
  return token
}

async function cf<T>(cfg: CfConfig, path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${resolveToken(cfg)}`,
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
    cache: 'no-store',
  })

  const data = (await res.json()) as {
    success: boolean
    result: T
    errors?: { code: number; message: string }[]
  }

  if (!data.success) {
    const msg =
      data.errors?.map((e) => e.message).join(', ') ||
      `Cloudflare request failed (${res.status})`
    throw new Error(msg)
  }

  return data.result
}

// Zone ID cache, keyed per domain so multiple domains can coexist.
const zoneCache = new Map<string, string>()

export async function getZoneId(cfg: CfConfig): Promise<string> {
  if (cfg.zoneId) return cfg.zoneId
  const cached = zoneCache.get(cfg.domain)
  if (cached) return cached
  const zones = await cf<{ id: string; name: string }[]>(
    cfg,
    `/zones?name=${cfg.domain}`,
  )
  const zone = zones.find((z) => z.name === cfg.domain) ?? zones[0]
  if (!zone) {
    throw new Error(
      `Zone untuk ${cfg.domain} tidak ditemukan. Pastikan domain terdaftar di akun Cloudflare token tersebut.`,
    )
  }
  zoneCache.set(cfg.domain, zone.id)
  return zone.id
}

export type DnsRecord = {
  id: string
  type: string
  name: string
  content: string
  proxied: boolean
  ttl: number
  created_on: string
}

export async function listRecords(cfg: CfConfig): Promise<DnsRecord[]> {
  const zoneId = await getZoneId(cfg)
  const records = await cf<DnsRecord[]>(
    cfg,
    `/zones/${zoneId}/dns_records?per_page=200`,
  )
  // Only show records that belong to the root domain (defensive)
  return records.filter((r) => r.name.endsWith(cfg.domain))
}

export type CreateInput = {
  subdomain: string
  type: 'A' | 'AAAA' | 'CNAME' | 'TXT'
  content: string
  proxied: boolean
}

function cleanSubdomain(subdomain: string) {
  const clean = subdomain.trim().toLowerCase().replace(/\.+$/, '')
  if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(clean)) {
    throw new Error(
      'Nama subdomain tidak valid. Gunakan huruf, angka, dan tanda minus saja.',
    )
  }
  return clean
}

export async function createRecord(
  cfg: CfConfig,
  input: CreateInput,
): Promise<DnsRecord> {
  const zoneId = await getZoneId(cfg)
  const fqdn = `${cleanSubdomain(input.subdomain)}.${cfg.domain}`

  // proxying only applies to A/AAAA/CNAME
  const proxied = input.type === 'TXT' ? false : input.proxied

  return cf<DnsRecord>(cfg, `/zones/${zoneId}/dns_records`, {
    method: 'POST',
    body: JSON.stringify({
      type: input.type,
      name: fqdn,
      content: input.content.trim(),
      proxied,
      ttl: 1,
    }),
  })
}

export type UpdateInput = {
  id: string
  subdomain: string
  type: 'A' | 'AAAA' | 'CNAME' | 'TXT'
  content: string
  proxied: boolean
}

export async function updateRecord(
  cfg: CfConfig,
  input: UpdateInput,
): Promise<DnsRecord> {
  const zoneId = await getZoneId(cfg)
  const fqdn = `${cleanSubdomain(input.subdomain)}.${cfg.domain}`
  const proxied = input.type === 'TXT' ? false : input.proxied

  return cf<DnsRecord>(cfg, `/zones/${zoneId}/dns_records/${input.id}`, {
    method: 'PUT',
    body: JSON.stringify({
      type: input.type,
      name: fqdn,
      content: input.content.trim(),
      proxied,
      ttl: 1,
    }),
  })
}

export async function deleteRecord(
  cfg: CfConfig,
  id: string,
): Promise<{ id: string }> {
  const zoneId = await getZoneId(cfg)
  return cf<{ id: string }>(cfg, `/zones/${zoneId}/dns_records/${id}`, {
    method: 'DELETE',
  })
}
