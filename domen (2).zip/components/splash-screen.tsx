'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

/**
 * SplashScreen — overlay yang muncul saat pertama kali website dibuka.
 * - Latar gelap glassmorphism (backdrop-blur + bg semi transparan)
 * - Logo "izsubdo.my.id" dengan glowing pulse + skeleton bar
 * - Fade-out halus setelah halaman selesai di-load (window "load")
 *   dengan durasi minimum agar tidak berkedip di koneksi cepat.
 */
export function SplashScreen({ minDuration = 1500 }: { minDuration?: number }) {
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    const start = performance.now()
    let timeoutId: number

    const hide = () => {
      const elapsed = performance.now() - start
      const remaining = Math.max(0, minDuration - elapsed)
      timeoutId = window.setTimeout(() => setVisible(false), remaining)
    }

    if (document.readyState === 'complete') {
      hide()
    } else {
      window.addEventListener('load', hide, { once: true })
    }

    return () => {
      window.removeEventListener('load', hide)
      window.clearTimeout(timeoutId)
    }
  }, [minDuration])

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          role="status"
          aria-label="Memuat halaman izsubdo.my.id"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.6, ease: 'easeInOut' } }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-6 bg-background/90 backdrop-blur-xl"
        >
          {/* aurora glow di belakang logo */}
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 aurora opacity-50"
          />

          {/* logo dengan glowing pulse */}
          <p className="animate-logo-glow relative font-heading text-3xl font-bold tracking-tight sm:text-4xl">
            <span className="text-primary">izsubdo</span>
            <span className="text-foreground/80">.my.id</span>
          </p>

          {/* skeleton pulse bars */}
          <div className="relative flex w-48 flex-col items-center gap-2">
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted/60">
              <motion.div
                animate={{ x: ['-100%', '100%'] }}
                transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
                className="h-full w-1/2 rounded-full bg-primary/80"
              />
            </div>
            <div className="h-1.5 w-2/3 animate-pulse rounded-full bg-muted/40" />
          </div>

          <span className="sr-only">Memuat halaman, mohon tunggu...</span>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
