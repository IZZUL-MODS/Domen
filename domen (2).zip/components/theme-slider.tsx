'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Sun, Moon } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useTheme } from '@/components/theme-provider'

/*
  Compact, free-floating day/night orb.
  - Small draggable button that can be moved anywhere (up / down / left / right).
  - A short tap/click toggles the theme; a drag just repositions it.
  - Position is remembered across reloads (localStorage).
*/

const SIZE = 40 // px — small orb
const MARGIN = 8 // px — keep away from screen edges
const STORAGE_KEY = 'theme-orb-pos'

export function ThemeSlider() {
  const { theme, setTheme } = useTheme()
  const isNight = theme === 'night'

  const [pos, setPos] = useState<{ x: number; y: number } | null>(null)
  const [dragging, setDragging] = useState(false)
  const drag = useRef<{
    startX: number
    startY: number
    baseX: number
    baseY: number
    moved: boolean
  } | null>(null)

  const clamp = useCallback((x: number, y: number) => {
    const maxX = window.innerWidth - SIZE - MARGIN
    const maxY = window.innerHeight - SIZE - MARGIN
    return {
      x: Math.min(maxX, Math.max(MARGIN, x)),
      y: Math.min(maxY, Math.max(MARGIN, y)),
    }
  }, [])

  // initial position: bottom-right, or restored from storage
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (saved) {
      try {
        const p = JSON.parse(saved)
        setPos(clamp(p.x, p.y))
        return
      } catch {
        // ignore malformed value
      }
    }
    setPos({
      x: window.innerWidth - SIZE - 20,
      y: window.innerHeight - SIZE - 96,
    })
  }, [clamp])

  // keep inside the viewport on resize
  useEffect(() => {
    if (!pos) return
    const onResize = () => setPos((p) => (p ? clamp(p.x, p.y) : p))
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [pos, clamp])

  const onPointerDown = useCallback(
    (e: React.PointerEvent) => {
      if (!pos) return
      e.currentTarget.setPointerCapture(e.pointerId)
      drag.current = {
        startX: e.clientX,
        startY: e.clientY,
        baseX: pos.x,
        baseY: pos.y,
        moved: false,
      }
      setDragging(true)
    },
    [pos],
  )

  const onPointerMove = useCallback(
    (e: React.PointerEvent) => {
      if (!drag.current) return
      const dx = e.clientX - drag.current.startX
      const dy = e.clientY - drag.current.startY
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) drag.current.moved = true
      setPos(clamp(drag.current.baseX + dx, drag.current.baseY + dy))
    },
    [clamp],
  )

  const endDrag = useCallback(() => {
    if (!drag.current) return
    const moved = drag.current.moved
    drag.current = null
    setDragging(false)
    if (!moved) {
      // treat as a tap → toggle theme
      setTheme(isNight ? 'day' : 'night')
    } else {
      setPos((p) => {
        if (p) localStorage.setItem(STORAGE_KEY, JSON.stringify(p))
        return p
      })
    }
  }, [isNight, setTheme])

  const onKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault()
        setTheme(isNight ? 'day' : 'night')
      }
    },
    [isNight, setTheme],
  )

  if (!pos) return null

  return (
    <button
      type="button"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      onKeyDown={onKeyDown}
      aria-label={
        isNight ? 'Mode malam aktif — geser atau ketuk untuk ganti' : 'Mode siang aktif — geser atau ketuk untuk ganti'
      }
      aria-pressed={isNight}
      className={cn(
        'fixed z-40 grid place-items-center rounded-full outline-none',
        'border border-border/60 backdrop-blur-md',
        'ring-1 ring-primary/30 focus-visible:ring-4 focus-visible:ring-primary',
        dragging ? 'cursor-grabbing scale-95' : 'cursor-grab active:scale-95',
        'touch-none select-none',
      )}
      style={{
        left: pos.x,
        top: pos.y,
        width: SIZE,
        height: SIZE,
        transition: dragging ? 'none' : 'transform 0.2s ease, box-shadow 0.3s ease',
        background: isNight
          ? 'radial-gradient(circle at 50% 35%, oklch(0.5 0.06 260 / 0.55), var(--primary))'
          : 'radial-gradient(circle at 50% 35%, oklch(0.98 0.05 90 / 0.7), var(--primary))',
        boxShadow: `0 6px 22px -6px var(--glow), 0 0 ${
          isNight ? 10 : 18
        }px var(--glow)`,
      }}
    >
      {/* Sun — day */}
      <span
        aria-hidden
        className="absolute inset-0 grid place-items-center transition-opacity duration-300"
        style={{ opacity: isNight ? 0 : 1 }}
      >
        <Sun className="h-4 w-4 animate-spin-slow text-primary-foreground drop-shadow" aria-hidden />
      </span>
      {/* Moon — night */}
      <span
        aria-hidden
        className="absolute inset-0 grid place-items-center transition-opacity duration-300"
        style={{ opacity: isNight ? 1 : 0 }}
      >
        <Moon className="h-4 w-4 text-primary-foreground drop-shadow" aria-hidden />
      </span>
    </button>
  )
}
