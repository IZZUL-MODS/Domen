'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'

export const DEFAULT_DOMAIN = 'izsubdo.my.id'
export const DEFAULT_HUE = 195

// Hardcoded gate credentials (simple admin lock, not hardened security)
const ADMIN_USER = 'izzul'
const ADMIN_PASS = 'IZZUL@198'

const SETTINGS_KEY = 'izsubdo-settings'
const AUTH_KEY = 'izsubdo-auth'

export type DomainEntry = {
  id: string
  domain: string
  token: string
  zoneId: string
  builtin?: boolean
}

const DEFAULT_ENTRY: DomainEntry = {
  id: 'default',
  domain: DEFAULT_DOMAIN,
  token: '',
  zoneId: '',
  builtin: true,
}

type PersistedSettings = {
  domains: DomainEntry[]
  activeDomainId: string
  hue: number
  rgb: boolean
}

const defaults: PersistedSettings = {
  domains: [DEFAULT_ENTRY],
  activeDomainId: 'default',
  hue: DEFAULT_HUE,
  rgb: false,
}

function makeId() {
  return `dom-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`
}

function normalizeDomain(raw: string) {
  return raw
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, '')
    .replace(/\/.*$/, '')
    .replace(/\.+$/, '')
}

/* Migrate old single-domain settings shape into the new multi-domain shape. */
function migrate(raw: unknown): PersistedSettings {
  const obj = (raw ?? {}) as Record<string, unknown>

  // New shape already
  if (Array.isArray(obj.domains) && obj.domains.length > 0) {
    const domains = (obj.domains as DomainEntry[]).filter(
      (d) => d && typeof d.domain === 'string' && d.domain.length > 0,
    )
    const hasDefault = domains.some((d) => d.id === 'default')
    const list = hasDefault ? domains : [DEFAULT_ENTRY, ...domains]
    const activeId =
      typeof obj.activeDomainId === 'string' &&
      list.some((d) => d.id === obj.activeDomainId)
        ? (obj.activeDomainId as string)
        : list[0].id
    return {
      domains: list,
      activeDomainId: activeId,
      hue: typeof obj.hue === 'number' ? obj.hue : DEFAULT_HUE,
      rgb: Boolean(obj.rgb),
    }
  }

  // Old shape: { domain, token, zoneId, hue, rgb }
  const domains: DomainEntry[] = [DEFAULT_ENTRY]
  const oldDomain =
    typeof obj.domain === 'string' ? normalizeDomain(obj.domain) : ''
  const oldToken = typeof obj.token === 'string' ? obj.token.trim() : ''
  const oldZone = typeof obj.zoneId === 'string' ? obj.zoneId.trim() : ''
  let activeId = 'default'

  if (oldDomain && oldDomain !== DEFAULT_DOMAIN && oldToken) {
    const migrated: DomainEntry = {
      id: makeId(),
      domain: oldDomain,
      token: oldToken,
      zoneId: oldZone,
    }
    domains.push(migrated)
    activeId = migrated.id
  }

  return {
    domains,
    activeDomainId: activeId,
    hue: typeof obj.hue === 'number' ? obj.hue : DEFAULT_HUE,
    rgb: Boolean(obj.rgb),
  }
}

type SettingsContextValue = {
  ready: boolean
  authed: boolean
  hue: number
  rgb: boolean
  domains: DomainEntry[]
  activeDomain: DomainEntry
  // convenience: the active root domain string used across the UI
  domain: string
  setActiveDomain: (id: string) => void
  addDomain: (domain: string, token: string, zoneId?: string) => string | null
  removeDomain: (id: string) => void
  // config headers for talking to /api/subdomains
  configHeaders: () => Record<string, string>
  update: (patch: Partial<Pick<PersistedSettings, 'hue' | 'rgb'>>) => void
  resetTheme: () => void
  login: (user: string, pass: string, remember: boolean) => boolean
  logout: () => void
}

const SettingsContext = createContext<SettingsContextValue | null>(null)

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<PersistedSettings>(defaults)
  const [authed, setAuthed] = useState(false)
  const [ready, setReady] = useState(false)

  // hydrate from storage (with migration from the old single-domain shape)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY)
      if (raw) {
        setSettings(migrate(JSON.parse(raw)))
      } else {
        // also check the legacy key so existing admins keep their config
        const legacy = localStorage.getItem('zulzz-settings')
        if (legacy) setSettings(migrate(JSON.parse(legacy)))
      }
    } catch {
      /* ignore */
    }
    const remembered =
      localStorage.getItem(AUTH_KEY) === '1' ||
      localStorage.getItem('zulzz-auth') === '1'
    const sessionAuthed =
      sessionStorage.getItem(AUTH_KEY) === '1' ||
      sessionStorage.getItem('zulzz-auth') === '1'
    setAuthed(remembered || sessionAuthed)
    setReady(true)
  }, [])

  // persist + apply theme to <html>
  useEffect(() => {
    if (!ready) return
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings))
    } catch {
      /* ignore */
    }
    const root = document.documentElement
    if (settings.rgb) {
      root.classList.add('rgb-mode')
      root.style.removeProperty('--h')
    } else {
      root.classList.remove('rgb-mode')
      root.style.setProperty('--h', String(settings.hue))
    }
  }, [settings, ready])

  const update = useCallback(
    (patch: Partial<Pick<PersistedSettings, 'hue' | 'rgb'>>) => {
      setSettings((prev) => ({ ...prev, ...patch }))
    },
    [],
  )

  const resetTheme = useCallback(() => {
    setSettings((prev) => ({ ...prev, hue: DEFAULT_HUE, rgb: false }))
  }, [])

  const setActiveDomain = useCallback((id: string) => {
    setSettings((prev) =>
      prev.domains.some((d) => d.id === id)
        ? { ...prev, activeDomainId: id }
        : prev,
    )
  }, [])

  const addDomain = useCallback(
    (domainRaw: string, tokenRaw: string, zoneRaw?: string): string | null => {
      const domain = normalizeDomain(domainRaw)
      const token = tokenRaw.trim()
      const zoneId = (zoneRaw ?? '').trim()

      if (!/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/.test(domain)) {
        return 'Format domain tidak valid. Contoh: contoh.com'
      }
      if (!token) {
        return 'API Token Cloudflare wajib diisi untuk menambah domain.'
      }

      let error: string | null = null
      setSettings((prev) => {
        if (prev.domains.some((d) => d.domain === domain)) {
          error = `Domain ${domain} sudah ada di daftar.`
          return prev
        }
        const entry: DomainEntry = { id: makeId(), domain, token, zoneId }
        return {
          ...prev,
          domains: [...prev.domains, entry],
          activeDomainId: entry.id,
        }
      })
      return error
    },
    [],
  )

  const removeDomain = useCallback((id: string) => {
    setSettings((prev) => {
      const target = prev.domains.find((d) => d.id === id)
      if (!target) return prev
      // Allow deletion of all domains including builtin
      const domains = prev.domains.filter((d) => d.id !== id)
      const activeDomainId =
        prev.activeDomainId === id ? domains[0]?.id ?? 'default' : prev.activeDomainId
      return { ...prev, domains, activeDomainId }
    })
  }, [])

  const login = useCallback(
    (user: string, pass: string, remember: boolean) => {
      const ok = user.trim() === ADMIN_USER && pass === ADMIN_PASS
      if (ok) {
        setAuthed(true)
        if (remember) {
          localStorage.setItem(AUTH_KEY, '1')
          sessionStorage.removeItem(AUTH_KEY)
        } else {
          sessionStorage.setItem(AUTH_KEY, '1')
          localStorage.removeItem(AUTH_KEY)
        }
      }
      return ok
    },
    [],
  )

  const logout = useCallback(() => {
    setAuthed(false)
    localStorage.removeItem(AUTH_KEY)
    sessionStorage.removeItem(AUTH_KEY)
  }, [])

  const activeDomain = useMemo<DomainEntry>(() => {
    return (
      settings.domains.find((d) => d.id === settings.activeDomainId) ??
      settings.domains[0] ??
      DEFAULT_ENTRY
    )
  }, [settings.domains, settings.activeDomainId])

  const configHeaders = useCallback((): Record<string, string> => {
    const h: Record<string, string> = {
      'x-cf-domain': activeDomain.domain || DEFAULT_DOMAIN,
    }
    if (activeDomain.token.trim()) h['x-cf-token'] = activeDomain.token.trim()
    if (activeDomain.zoneId.trim()) h['x-cf-zone'] = activeDomain.zoneId.trim()
    return h
  }, [activeDomain])

  const value = useMemo<SettingsContextValue>(
    () => ({
      ready,
      authed,
      hue: settings.hue,
      rgb: settings.rgb,
      domains: settings.domains,
      activeDomain,
      domain: activeDomain.domain,
      setActiveDomain,
      addDomain,
      removeDomain,
      configHeaders,
      update,
      resetTheme,
      login,
      logout,
    }),
    [
      ready,
      authed,
      settings.hue,
      settings.rgb,
      settings.domains,
      activeDomain,
      setActiveDomain,
      addDomain,
      removeDomain,
      configHeaders,
      update,
      resetTheme,
      login,
      logout,
    ],
  )

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const ctx = useContext(SettingsContext)
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider')
  return ctx
}
