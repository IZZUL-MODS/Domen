'use client'

import useSWR from 'swr'
import { useState } from 'react'
import {
  Loader2,
  RefreshCw,
  Search,
  Globe,
  AlertCircle,
  Pencil,
  Trash2,
  X,
  Check,
} from 'lucide-react'
import { ScrollReveal } from '@/components/scroll-reveal'
import { Button } from '@/components/ui/button'
import { useSettings } from '@/components/settings-provider'
import { cn } from '@/lib/utils'

type DnsRecord = {
  id: string
  type: string
  name: string
  content: string
  proxied: boolean
  ttl: number
}

function makeFetcher(headers: Record<string, string>) {
  return ([url]: [string, string]) =>
    fetch(url, { headers }).then(async (r) => {
      const data = await r.json()
      if (!r.ok) throw new Error(data.error || 'Gagal memuat data')
      return data
    })
}

const typeColors: Record<string, string> = {
  A: 'bg-chart-1/15 text-chart-1',
  AAAA: 'bg-chart-2/15 text-chart-2',
  CNAME: 'bg-chart-3/15 text-chart-3',
  TXT: 'bg-chart-4/15 text-chart-4',
}

const RECORD_TYPES = ['A', 'AAAA', 'CNAME', 'TXT'] as const

function labelOf(name: string, root: string) {
  if (name === root) return '@'
  return name.replace(`.${root}`, '')
}

export function ListSection() {
  const {
    domain: ROOT_DOMAIN,
    domains,
    activeDomain,
    setActiveDomain,
    configHeaders,
  } = useSettings()
  const { data, error, isLoading, mutate, isValidating } = useSWR<{
    records: DnsRecord[]
  }>(['/api/subdomains', ROOT_DOMAIN], makeFetcher(configHeaders()))
  const [q, setQ] = useState('')
  const [editing, setEditing] = useState<DnsRecord | null>(null)
  const [deleting, setDeleting] = useState<DnsRecord | null>(null)

  const records = (data?.records ?? []).filter(
    (r) =>
      r.name.toLowerCase().includes(q.toLowerCase()) ||
      r.content.toLowerCase().includes(q.toLowerCase()),
  )

  return (
    <section className="mx-auto w-full max-w-3xl px-4 pb-24 pt-16 sm:pt-24">
      <ScrollReveal className="text-center">
        <h1 className="font-heading text-4xl font-bold tracking-tight text-balance sm:text-6xl">
          Semua <span className="text-primary text-glow">subdomain</span>
        </h1>
        <p className="mx-auto mt-4 max-w-md text-pretty text-muted-foreground">
          Daftar lengkap record DNS yang terdaftar pada{' '}
          <span className="font-mono text-primary">{ROOT_DOMAIN}</span>.
        </p>
      </ScrollReveal>

      {/* domain switcher */}
      {domains.length > 1 && (
        <ScrollReveal delay={60} className="mt-8 flex flex-wrap justify-center gap-2">
          {domains.map((d) => (
            <button
              key={d.id}
              type="button"
              onClick={() => setActiveDomain(d.id)}
              aria-pressed={d.id === activeDomain.id}
              className={cn(
                'rounded-full border px-4 py-2 font-mono text-xs font-medium transition-all',
                d.id === activeDomain.id
                  ? 'border-primary bg-primary text-primary-foreground'
                  : 'border-border bg-background/60 text-muted-foreground hover:border-primary/50 hover:text-foreground',
              )}
            >
              {d.domain}
            </button>
          ))}
        </ScrollReveal>
      )}

      {/* controls */}
      <ScrollReveal delay={100} className="mt-10 flex items-center gap-3">
        <div className="flex flex-1 items-center gap-2 rounded-xl border border-input bg-background/60 px-3 focus-within:ring-2 focus-within:ring-ring">
          <Search className="h-4 w-4 text-muted-foreground" aria-hidden />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cari subdomain..."
            className="w-full bg-transparent py-3 font-mono text-sm outline-none placeholder:text-muted-foreground/60"
          />
        </div>
        <Button
          type="button"
          variant="secondary"
          onClick={() => mutate()}
          className="h-12 rounded-xl"
        >
          <RefreshCw
            className={cn('h-4 w-4', isValidating && 'animate-spin')}
            aria-hidden
          />
          <span className="sr-only sm:not-sr-only">Refresh</span>
        </Button>
      </ScrollReveal>

      {/* states */}
      <div className="mt-8">
        {isLoading && (
          <div className="flex items-center justify-center gap-3 rounded-2xl border border-border bg-card/40 py-16 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" aria-hidden />
            Memuat subdomain...
          </div>
        )}

        {error && (
          <div className="flex flex-col items-center gap-2 rounded-2xl border border-destructive/30 bg-destructive/10 py-12 text-center text-destructive">
            <AlertCircle className="h-6 w-6" aria-hidden />
            <p className="font-medium">{error.message}</p>
            <p className="text-sm text-destructive/80">
              Pastikan token Cloudflare sudah benar.
            </p>
          </div>
        )}

        {!isLoading && !error && records.length === 0 && (
          <div className="flex flex-col items-center gap-2 rounded-2xl border border-border bg-card/40 py-16 text-center text-muted-foreground">
            <Globe className="h-7 w-7" aria-hidden />
            <p>Belum ada subdomain yang cocok.</p>
          </div>
        )}

        <ul className="space-y-3">
          {records.map((r, i) => (
            <ScrollReveal as="li" key={r.id} delay={Math.min(i * 50, 400)}>
              <div className="group flex items-center justify-between gap-3 rounded-2xl border border-border bg-card/60 px-5 py-4 backdrop-blur-md transition-all hover:border-primary/50 hover:bg-card">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span
                      className={cn(
                        'rounded-md px-2 py-0.5 font-mono text-[11px] font-bold',
                        typeColors[r.type] ?? 'bg-muted text-muted-foreground',
                      )}
                    >
                      {r.type}
                    </span>
                    {r.proxied && (
                      <span className="rounded-md bg-primary/15 px-2 py-0.5 font-mono text-[11px] font-bold text-primary">
                        PROXIED
                      </span>
                    )}
                  </div>
                  <p className="mt-1.5 truncate font-mono text-base font-semibold text-foreground">
                    {r.name}
                  </p>
                  <p className="truncate font-mono text-xs text-muted-foreground">
                    → {r.content}
                  </p>
                </div>

                {/* edit / delete actions */}
                <div className="flex shrink-0 items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setEditing(r)}
                    aria-label={`Edit ${r.name}`}
                    className="grid h-9 w-9 place-items-center rounded-xl border border-border bg-background/50 text-muted-foreground transition-colors hover:border-primary/50 hover:bg-primary/10 hover:text-primary"
                  >
                    <Pencil className="h-4 w-4" aria-hidden />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleting(r)}
                    aria-label={`Hapus ${r.name}`}
                    className="grid h-9 w-9 place-items-center rounded-xl border border-border bg-background/50 text-muted-foreground transition-colors hover:border-destructive/50 hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" aria-hidden />
                  </button>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </ul>

        {!isLoading && !error && data && (
          <p className="mt-6 text-center font-mono text-xs text-muted-foreground">
            {records.length} record ditampilkan
          </p>
        )}
      </div>

      {editing && (
        <EditDialog
          record={editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null)
            mutate()
          }}
        />
      )}

      {deleting && (
        <DeleteDialog
          record={deleting}
          onClose={() => setDeleting(null)}
          onDeleted={() => {
            setDeleting(null)
            mutate()
          }}
        />
      )}
    </section>
  )
}

function Overlay({
  children,
  onClose,
}: {
  children: React.ReactNode
  onClose: () => void
}) {
  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
    >
      <button
        type="button"
        aria-label="Tutup"
        onClick={onClose}
        className="absolute inset-0 bg-background/70 backdrop-blur-sm"
      />
      <div className="relative w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-2xl shadow-primary/20">
        {children}
      </div>
    </div>
  )
}

function EditDialog({
  record,
  onClose,
  onSaved,
}: {
  record: DnsRecord
  onClose: () => void
  onSaved: () => void
}) {
  const { domain: ROOT_DOMAIN, configHeaders } = useSettings()
  const [subdomain, setSubdomain] = useState(labelOf(record.name, ROOT_DOMAIN))
  const [type, setType] = useState(record.type)
  const [content, setContent] = useState(record.content)
  const [proxied, setProxied] = useState(record.proxied)
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const canProxy = type === 'A' || type === 'AAAA' || type === 'CNAME'

  async function handleSave() {
    setSaving(true)
    setErr(null)
    try {
      const res = await fetch(`/api/subdomains/${record.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', ...configHeaders() },
        body: JSON.stringify({ subdomain, type, content, proxied }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Gagal menyimpan perubahan')
      onSaved()
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Gagal menyimpan perubahan')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Overlay onClose={onClose}>
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-xl font-bold">
          Edit <span className="text-primary">subdomain</span>
        </h2>
        <button
          type="button"
          onClick={onClose}
          aria-label="Tutup"
          className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <X className="h-4 w-4" aria-hidden />
        </button>
      </div>

      <div className="mt-5 space-y-4">
        <div>
          <label className="font-mono text-xs font-medium text-muted-foreground">
            Nama subdomain
          </label>
          <div className="mt-1.5 flex items-center rounded-xl border border-input bg-background/60 px-3 focus-within:ring-2 focus-within:ring-ring">
            <input
              value={subdomain}
              onChange={(e) => setSubdomain(e.target.value)}
              className="w-full bg-transparent py-2.5 font-mono text-sm outline-none"
            />
            <span className="shrink-0 font-mono text-sm text-muted-foreground">
                .{ROOT_DOMAIN}

            </span>
          </div>
        </div>

        <div className="flex gap-3">
          <div className="w-32">
            <label className="font-mono text-xs font-medium text-muted-foreground">
              Tipe
            </label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-input bg-background/60 px-3 py-2.5 font-mono text-sm outline-none focus:ring-2 focus:ring-ring"
            >
              {RECORD_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div className="flex-1">
            <label className="font-mono text-xs font-medium text-muted-foreground">
              Konten / target
            </label>
            <input
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-input bg-background/60 px-3 py-2.5 font-mono text-sm outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </div>

        {canProxy && (
          <label className="flex cursor-pointer items-center justify-between rounded-xl border border-border bg-background/40 px-4 py-3">
            <span className="font-mono text-sm">Proxy lewat Cloudflare</span>
            <input
              type="checkbox"
              checked={proxied}
              onChange={(e) => setProxied(e.target.checked)}
              className="h-5 w-5 accent-[var(--primary)]"
            />
          </label>
        )}

        {err && (
          <p className="flex items-center gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
            <AlertCircle className="h-4 w-4 shrink-0" aria-hidden />
            {err}
          </p>
        )}

        <div className="flex gap-3 pt-1">
          <Button
            type="button"
            variant="secondary"
            onClick={onClose}
            className="flex-1 rounded-xl"
          >
            Batal
          </Button>
          <Button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="flex-1 rounded-xl"
          >
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
            ) : (
              <Check className="h-4 w-4" aria-hidden />
            )}
            Simpan
          </Button>
        </div>
      </div>
    </Overlay>
  )
}

function DeleteDialog({
  record,
  onClose,
  onDeleted,
}: {
  record: DnsRecord
  onClose: () => void
  onDeleted: () => void
}) {
  const { configHeaders } = useSettings()
  const [deleting, setDeleting] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  async function handleDelete() {
    setDeleting(true)
    setErr(null)
    try {
      const res = await fetch(`/api/subdomains/${record.id}`, {
        method: 'DELETE',
        headers: configHeaders(),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Gagal menghapus subdomain')
      onDeleted()
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Gagal menghapus subdomain')
    } finally {
      setDeleting(false)
    }
  }

  return (
    <Overlay onClose={onClose}>
      <div className="flex flex-col items-center text-center">
        <div className="grid h-12 w-12 place-items-center rounded-full bg-destructive/15 text-destructive">
          <Trash2 className="h-6 w-6" aria-hidden />
        </div>
        <h2 className="mt-4 font-heading text-xl font-bold">Hapus subdomain?</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Record{' '}
          <span className="font-mono font-semibold text-foreground">
            {record.name}
          </span>{' '}
          akan dihapus permanen dari Cloudflare. Tindakan ini tidak bisa
          dibatalkan.
        </p>

        {err && (
          <p className="mt-4 flex items-center gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
            <AlertCircle className="h-4 w-4 shrink-0" aria-hidden />
            {err}
          </p>
        )}

        <div className="mt-6 flex w-full gap-3">
          <Button
            type="button"
            variant="secondary"
            onClick={onClose}
            className="flex-1 rounded-xl"
          >
            Batal
          </Button>
          <Button
            type="button"
            variant="destructive"
            onClick={handleDelete}
            disabled={deleting}
            className="flex-1 rounded-xl"
          >
            {deleting ? (
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
            ) : (
              <Trash2 className="h-4 w-4" aria-hidden />
            )}
            Hapus
          </Button>
        </div>
      </div>
    </Overlay>
  )
}
