'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'

/** Micro-copy yang ditampilkan bergantian selama proses berjalan. */
export const PROCESS_STEPS = [
  'Memeriksa ketersediaan subdomain...',
  'Menghubungkan ke Cloudflare DNS...',
  'Mengaktifkan SSL & Proteksi...',
] as const

export const PROCESS_DONE = 'Subdomain siap digunakan!'

/**
 * Hook: memutar micro-copy PROCESS_STEPS selama `active` bernilai true.
 * Berhenti di step terakhir (tidak looping) agar terasa seperti progres nyata.
 */
export function useProcessSteps(active: boolean, intervalMs = 1400) {
  const [step, setStep] = useState(0)

  useEffect(() => {
    if (!active) {
      setStep(0)
      return
    }
    const id = window.setInterval(
      () => setStep((s) => Math.min(s + 1, PROCESS_STEPS.length - 1)),
      intervalMs,
    )
    return () => window.clearInterval(id)
  }, [active, intervalMs])

  return active ? PROCESS_STEPS[step] : null
}

/**
 * Indikator proses: spinner + micro-copy yang berganti dengan animasi halus.
 * Dibungkus aria-live="polite" agar screen reader membacakan setiap perubahan status.
 */
export function ProcessStatus({ message }: { message: string | null }) {
  return (
    <span
      aria-live="polite"
      className="inline-flex items-center gap-2 overflow-hidden"
    >
      <Loader2 className="h-5 w-5 shrink-0 animate-spin" aria-hidden />
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={message}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="truncate text-sm sm:text-base"
        >
          {message}
        </motion.span>
      </AnimatePresence>
    </span>
  )
}

/**
 * Pembungkus tombol dengan pulsing glow-border saat proses berjalan.
 * Mencegah kesan "macet" dan memberi sinyal visual bahwa tombol sedang disabled.
 */
export function GlowingButtonWrapper({
  active,
  children,
  className,
}: {
  active: boolean
  children: React.ReactNode
  className?: string
}) {
  return (
    <div className={cn(active && 'animate-glow-pulse', className)}>
      {children}
    </div>
  )
}
