'use client'

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react'

type Theme = 'day' | 'night'

type ThemeContextValue = {
  theme: Theme
  setTheme: (t: Theme) => void
  toggleTheme: () => void
}

const ThemeContext = createContext<ThemeContextValue | null>(null)

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>('night')

  // hydrate from storage / system on mount
  useEffect(() => {
    const stored = (localStorage.getItem('izsubdo-theme') ??
      localStorage.getItem('zulzz-theme')) as Theme | null
    if (stored === 'day' || stored === 'night') {
      setThemeState(stored)
    } else {
      const prefersDark = window.matchMedia(
        '(prefers-color-scheme: dark)',
      ).matches
      setThemeState(prefersDark ? 'night' : 'day')
    }
  }, [])

  // apply to <html>
  useEffect(() => {
    const root = document.documentElement
    if (theme === 'night') root.classList.add('dark')
    else root.classList.remove('dark')
    localStorage.setItem('izsubdo-theme', theme)
  }, [theme])

  const setTheme = (t: Theme) => setThemeState(t)
  const toggleTheme = () =>
    setThemeState((prev) => (prev === 'night' ? 'day' : 'night'))

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider')
  return ctx
}
