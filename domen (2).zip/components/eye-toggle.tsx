'use client'

import { cn } from '@/lib/utils'

/*
  Custom password visibility toggle.
  - When `revealed` is false → an eye with an animated "-" line drawn across it.
  - When `revealed` is true  → the line retracts and the eye "opens".
  Pure SVG so the line/slash animates smoothly via stroke-dashoffset.
*/
export function EyeToggle({
  revealed,
  onToggle,
  className,
}: {
  revealed: boolean
  onToggle: () => void
  className?: string
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-pressed={revealed}
      aria-label={revealed ? 'Sembunyikan password' : 'Lihat password'}
      title={revealed ? 'Sembunyikan password' : 'Lihat password'}
      className={cn(
        'group grid h-9 w-9 shrink-0 place-items-center rounded-xl text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary',
        className,
      )}
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        className="h-5 w-5"
        aria-hidden
      >
        {/* eye outline */}
        <path
          d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          className={cn(
            'transition-transform duration-300 origin-center',
            revealed ? 'scale-100' : 'scale-y-[0.82]',
          )}
        />
        {/* pupil — shrinks away when hidden */}
        <circle
          cx="12"
          cy="12"
          r="3"
          fill="currentColor"
          className={cn(
            'origin-center transition-all duration-300',
            revealed ? 'scale-100 opacity-100' : 'scale-50 opacity-40',
          )}
        />
        {/* the morphing "-" slash line across the eye */}
        <line
          x1="4"
          y1="20"
          x2="20"
          y2="4"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          pathLength={1}
          strokeDasharray={1}
          style={{
            strokeDashoffset: revealed ? 1 : 0,
            transition: 'stroke-dashoffset 0.35s cubic-bezier(0.16,1,0.3,1)',
          }}
        />
      </svg>
    </button>
  )
}
