'use client'

import { useState } from 'react'
import { Toolbar, type View } from '@/components/toolbar'
import { SplashScreen } from '@/components/splash-screen'
import { HomeSection } from '@/components/sections/home-section'
import { ListSection } from '@/components/sections/list-section'
import { AboutSection } from '@/components/sections/about-section'
import { SettingsSection } from '@/components/sections/settings-section'

export default function Page() {
  const [view, setView] = useState<View>('home')

  return (
    <main className="relative min-h-dvh overflow-x-hidden">
      <SplashScreen />
      {/* animated brand-colored aurora backdrop */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10 aurora opacity-70"
      />
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10 bg-background/40"
      />

      <Toolbar view={view} onChange={setView} />

      {view === 'home' && <HomeSection />}
      {view === 'list' && <ListSection />}
      {view === 'about' && <AboutSection />}
      {view === 'settings' && <SettingsSection />}
    </main>
  )
}
