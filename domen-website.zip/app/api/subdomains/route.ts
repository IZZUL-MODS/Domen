import { NextResponse } from 'next/server'
import { listRecords, createRecord } from '@/lib/cloudflare'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const records = await listRecords()
    return NextResponse.json({ records })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { subdomain, type, content, proxied } = body ?? {}

    if (!subdomain || !type || !content) {
      return NextResponse.json(
        { error: 'subdomain, type, dan content wajib diisi.' },
        { status: 400 },
      )
    }

    const record = await createRecord({
      subdomain,
      type,
      content,
      proxied: Boolean(proxied),
    })

    return NextResponse.json({ record })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
