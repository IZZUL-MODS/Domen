// Server-only Cloudflare helper. Never import this from client components.

export const ROOT_DOMAIN = 'zulzz.my.id'

const API_BASE = 'https://api.cloudflare.com/client/v4'

function getToken() {
  const token = process.env.CLOUDFLARE_API_TOKEN
  if (!token) {
    throw new Error('CLOUDFLARE_API_TOKEN is not set')
  }
  return token
}

async function cf<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${getToken()}`,
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
    cache: 'no-store',
  })

  const data = (await res.json()) as {
    success: boolean
    result: T
    errors?: { code: number; message: string }[]
  }

  if (!data.success) {
    const msg =
      data.errors?.map((e) => e.message).join(', ') ||
      `Cloudflare request failed (${res.status})`
    throw new Error(msg)
  }

  return data.result
}

let cachedZoneId: string | null = null

export async function getZoneId(): Promise<string> {
  if (cachedZoneId) return cachedZoneId
  const zones = await cf<{ id: string; name: string }[]>(
    `/zones?name=${ROOT_DOMAIN}`,
  )
  const zone = zones.find((z) => z.name === ROOT_DOMAIN) ?? zones[0]
  if (!zone) throw new Error(`Zone for ${ROOT_DOMAIN} not found`)
  cachedZoneId = zone.id
  return zone.id
}

export type DnsRecord = {
  id: string
  type: string
  name: string
  content: string
  proxied: boolean
  ttl: number
  created_on: string
}

export async function listRecords(): Promise<DnsRecord[]> {
  const zoneId = await getZoneId()
  const records = await cf<DnsRecord[]>(
    `/zones/${zoneId}/dns_records?per_page=200`,
  )
  // Only show records that belong to the root domain (defensive)
  return records.filter((r) => r.name.endsWith(ROOT_DOMAIN))
}

export type CreateInput = {
  subdomain: string
  type: 'A' | 'AAAA' | 'CNAME' | 'TXT'
  content: string
  proxied: boolean
}

export async function createRecord(input: CreateInput): Promise<DnsRecord> {
  const zoneId = await getZoneId()

  const clean = input.subdomain.trim().toLowerCase().replace(/\.+$/, '')
  if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(clean)) {
    throw new Error(
      'Nama subdomain tidak valid. Gunakan huruf, angka, dan tanda minus saja.',
    )
  }

  const fqdn = `${clean}.${ROOT_DOMAIN}`

  // proxying only applies to A/AAAA/CNAME
  const proxied =
    input.type === 'TXT' ? false : input.proxied

  return cf<DnsRecord>(`/zones/${zoneId}/dns_records`, {
    method: 'POST',
    body: JSON.stringify({
      type: input.type,
      name: fqdn,
      content: input.content.trim(),
      proxied,
      ttl: 1,
    }),
  })
}

export type UpdateInput = {
  id: string
  subdomain: string
  type: 'A' | 'AAAA' | 'CNAME' | 'TXT'
  content: string
  proxied: boolean
}

export async function updateRecord(input: UpdateInput): Promise<DnsRecord> {
  const zoneId = await getZoneId()

  const clean = input.subdomain.trim().toLowerCase().replace(/\.+$/, '')
  if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(clean)) {
    throw new Error(
      'Nama subdomain tidak valid. Gunakan huruf, angka, dan tanda minus saja.',
    )
  }

  const fqdn = `${clean}.${ROOT_DOMAIN}`
  const proxied = input.type === 'TXT' ? false : input.proxied

  return cf<DnsRecord>(`/zones/${zoneId}/dns_records/${input.id}`, {
    method: 'PUT',
    body: JSON.stringify({
      type: input.type,
      name: fqdn,
      content: input.content.trim(),
      proxied,
      ttl: 1,
    }),
  })
}

export async function deleteRecord(id: string): Promise<{ id: string }> {
  const zoneId = await getZoneId()
  return cf<{ id: string }>(`/zones/${zoneId}/dns_records/${id}`, {
    method: 'DELETE',
  })
}
