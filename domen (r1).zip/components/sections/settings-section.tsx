'use client'

import { useState } from 'react'
import {
  Lock,
  User,
  LogOut,
  Globe,
  KeyRound,
  Palette,
  Check,
  AlertCircle,
  ShieldAlert,
  RotateCcw,
  Sparkles,
  Pipette,
  Plus,
  Trash2,
  Loader2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ScrollReveal } from '@/components/scroll-reveal'
import { EyeToggle } from '@/components/eye-toggle'
import { useSettings } from '@/components/settings-provider'
import { cn } from '@/lib/utils'

const PRESETS: { name: string; hue: number }[] = [
  { name: 'Cyan', hue: 195 },
  { name: 'Ungu', hue: 300 },
  { name: 'Magenta', hue: 340 },
  { name: 'Merah', hue: 25 },
  { name: 'Oranye', hue: 60 },
  { name: 'Hijau', hue: 150 },
  { name: 'Aqua', hue: 215 },
  { name: 'Biru', hue: 260 },
  { name: 'Pink', hue: 360 },
]

/* Convert a hex color (#rrggbb) into an approximate hue [0..360]. */
function hexToHue(hex: string): number {
  const m = hex.replace('#', '')
  const r = parseInt(m.slice(0, 2), 16) / 255
  const g = parseInt(m.slice(2, 4), 16) / 255
  const b = parseInt(m.slice(4, 6), 16) / 255
  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  const d = max - min
  if (d === 0) return 0
  let h = 0
  if (max === r) h = ((g - b) / d) % 6
  else if (max === g) h = (b - r) / d + 2
  else h = (r - g) / d + 4
  h = Math.round(h * 60)
  return (h + 360) % 360
}

/* Approximate hue [0..360] -> hex for the color-picker swatch. */
function hueToHex(hue: number): string {
  const s = 0.85
  const l = 0.55
  const c = (1 - Math.abs(2 * l - 1)) * s
  const x = c * (1 - Math.abs(((hue / 60) % 2) - 1))
  const mm = l - c / 2
  let r = 0
  let g = 0
  let b = 0
  if (hue < 60) [r, g, b] = [c, x, 0]
  else if (hue < 120) [r, g, b] = [x, c, 0]
  else if (hue < 180) [r, g, b] = [0, c, x]
  else if (hue < 240) [r, g, b] = [0, x, c]
  else if (hue < 300) [r, g, b] = [x, 0, c]
  else [r, g, b] = [c, 0, x]
  const to = (v: number) =>
    Math.round((v + mm) * 255)
      .toString(16)
      .padStart(2, '0')
  return `#${to(r)}${to(g)}${to(b)}`
}

export function SettingsSection() {
  const { authed } = useSettings()
  return (
    <section className="mx-auto w-full max-w-2xl px-4 pb-32 pt-16 sm:pt-24">
      <ScrollReveal className="text-center">
        <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs uppercase tracking-widest text-primary">
          <Sparkles className="h-3.5 w-3.5" aria-hidden />
          Panel admin
        </span>
        <h1 className="font-heading text-4xl font-black tracking-tight text-balance sm:text-6xl">
          <span className="shimmer-text">Pengaturan</span>{' '}
          <span className="text-primary text-glow">website</span>
        </h1>
        <p className="mx-auto mt-4 max-w-md text-pretty leading-relaxed text-muted-foreground">
          Tambah domain baru, kelola daftar domain aktif, dan atur warna tema —
          semua berubah langsung di seluruh website.
        </p>
      </ScrollReveal>

      <div className="mt-10">{authed ? <Panels /> : <LoginForm />}</div>
    </section>
  )
}

function LoginForm() {
  const { login } = useSettings()
  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')
  const [remember, setRemember] = useState(true)
  const [show, setShow] = useState(false)
  const [err, setErr] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const ok = login(user, pass, remember)
    setErr(!ok)
  }

  return (
    <ScrollReveal>
      <form
        onSubmit={handleSubmit}
        className="box-glow relative mx-auto max-w-md overflow-hidden rounded-3xl border border-border bg-card/90 p-6 backdrop-blur-xl sm:p-8"
      >
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-primary/15 text-primary animate-float-slow">
          <Lock className="h-6 w-6" aria-hidden />
        </div>
        <h2 className="mt-4 text-center font-heading text-xl font-bold">
          Login diperlukan
        </h2>
        <p className="mt-1 text-center text-sm text-muted-foreground">
          Hanya admin yang bisa mengubah pengaturan.
        </p>

        <div className="mt-6 flex flex-col gap-4">
          <div>
            <label
              htmlFor="user"
              className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
            >
              Username
            </label>
            <div className="flex items-center rounded-xl border border-input bg-background/60 px-3 transition-shadow focus-within:ring-2 focus-within:ring-ring">
              <User className="h-4 w-4 text-muted-foreground" aria-hidden />
              <input
                id="user"
                value={user}
                onChange={(e) => setUser(e.target.value)}
                autoComplete="username"
                placeholder="username"
                className="w-full bg-transparent px-2 py-3 text-sm outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="pass"
              className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
            >
              Password
            </label>
            <div className="flex items-center rounded-xl border border-input bg-background/60 pl-3 pr-1.5 transition-shadow focus-within:ring-2 focus-within:ring-ring">
              <KeyRound className="h-4 w-4 text-muted-foreground" aria-hidden />
              <input
                id="pass"
                type={show ? 'text' : 'password'}
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                autoComplete="current-password"
                placeholder="••••••••"
                className="w-full bg-transparent px-2 py-3 text-sm outline-none"
              />
              <EyeToggle revealed={show} onToggle={() => setShow((s) => !s)} />
            </div>
          </div>

          <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-border bg-background/40 px-4 py-3 transition-colors hover:border-primary/40">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="h-4 w-4 accent-[var(--primary)]"
            />
            <span className="text-sm">
              <span className="font-medium">Remember me</span>
              <span className="block text-xs text-muted-foreground">
                Tetap login, tak perlu masukkan user &amp; password lagi.
              </span>
            </span>
          </label>

          {err && (
            <p className="flex items-center gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
              <AlertCircle className="h-4 w-4 shrink-0" aria-hidden />
              Username atau password salah.
            </p>
          )}

          <Button type="submit" className="h-12 w-full rounded-xl font-heading">
            <Lock className="h-4 w-4" aria-hidden />
            Masuk
          </Button>
        </div>
      </form>
    </ScrollReveal>
  )
}

function Card({
  icon: Icon,
  title,
  desc,
  children,
}: {
  icon: typeof Globe
  title: string
  desc: string
  children: React.ReactNode
}) {
  return (
    <div className="group relative overflow-hidden rounded-3xl border border-border bg-card/90 p-5 backdrop-blur-xl transition-all hover:border-primary/50 hover:shadow-[0_18px_60px_-32px_var(--glow)] sm:p-6">
      <div className="relative flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15 text-primary">
          <Icon className="h-5 w-5" aria-hidden />
        </span>
        <div>
          <h3 className="font-heading text-base font-semibold">{title}</h3>
          <p className="text-xs text-muted-foreground">{desc}</p>
        </div>
      </div>
      <div className="relative mt-5">{children}</div>
    </div>
  )
}

function Panels() {
  const {
    hue,
    rgb,
    domains,
    activeDomain,
    setActiveDomain,
    addDomain,
    removeDomain,
    update,
    resetTheme,
    logout,
  } = useSettings()

  const [newDomain, setNewDomain] = useState('')
  const [newToken, setNewToken] = useState('')
  const [newZone, setNewZone] = useState('')
  const [showToken, setShowToken] = useState(false)
  const [formErr, setFormErr] = useState<string | null>(null)
  const [added, setAdded] = useState(false)
  const [adding, setAdding] = useState(false)

  function handleAddDomain(e: React.FormEvent) {
    e.preventDefault()
    setFormErr(null)
    setAdding(true)
    const err = addDomain(newDomain, newToken, newZone)
    setAdding(false)
    if (err) {
      setFormErr(err)
      return
    }
    setNewDomain('')
    setNewToken('')
    setNewZone('')
    setShowToken(false)
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <div className="flex flex-col gap-6">
      {/* DOMAIN LIST */}
      <ScrollReveal>
        <Card
          icon={Globe}
          title="Domain terdaftar"
          desc="Semua domain yang bisa dipakai untuk membuat subdomain."
        >
          <ul className="flex flex-col gap-2.5">
            {domains.map((d) => {
              const isActive = d.id === activeDomain.id
              return (
                <li key={d.id} className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveDomain(d.id)}
                    aria-pressed={isActive}
                    className={cn(
                      'flex min-w-0 flex-1 items-center justify-between gap-3 rounded-xl border px-4 py-3 text-left transition-all',
                      isActive
                        ? 'border-primary bg-primary/10'
                        : 'border-border bg-background/40 hover:border-primary/40',
                    )}
                  >
                    <span className="min-w-0">
                      <span className="block truncate font-mono text-sm font-semibold">
                        {d.domain}
                      </span>
                      <span className="block text-xs text-muted-foreground">
                        {d.builtin
                          ? 'Domain bawaan · token server'
                          : d.token
                            ? 'Token tersimpan di browser'
                            : 'Tanpa token'}
                      </span>
                    </span>
                    {isActive && (
                      <span className="flex shrink-0 items-center gap-1 rounded-full bg-primary/15 px-2.5 py-1 font-mono text-[11px] font-bold text-primary">
                        <Check className="h-3 w-3" aria-hidden />
                        AKTIF
                      </span>
                    )}
                  </button>
                  {!d.builtin && (
                    <button
                      type="button"
                      onClick={() => removeDomain(d.id)}
                      aria-label={`Hapus domain ${d.domain}`}
                      className="grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-border bg-background/50 text-muted-foreground transition-colors hover:border-destructive/50 hover:bg-destructive/10 hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" aria-hidden />
                    </button>
                  )}
                </li>
              )
            })}
          </ul>
          <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
            Klik salah satu domain untuk menjadikannya aktif. Domain aktif
            dipakai di form pembuatan subdomain dan daftar record.
          </p>
        </Card>
      </ScrollReveal>

      {/* ADD DOMAIN */}
      <ScrollReveal delay={80}>
        <Card
          icon={Plus}
          title="Tambah domain"
          desc="Hubungkan domain baru dengan kredensial Cloudflare-nya sendiri."
        >
          <form onSubmit={handleAddDomain} className="flex flex-col gap-4">
            <div>
              <label
                htmlFor="new-domain"
                className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
              >
                Nama domain
              </label>
              <input
                id="new-domain"
                value={newDomain}
                onChange={(e) => setNewDomain(e.target.value)}
                placeholder="contoh.com"
                required
                autoComplete="off"
                className="w-full rounded-xl border border-input bg-background/60 px-4 py-3 font-mono text-sm outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <div>
              <label
                htmlFor="new-token"
                className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
              >
                API Token Cloudflare{' '}
                <span className="text-destructive">*wajib</span>
              </label>
              <div className="flex items-center rounded-xl border border-input bg-background/60 pl-4 pr-1.5 focus-within:ring-2 focus-within:ring-ring">
                <input
                  id="new-token"
                  type={showToken ? 'text' : 'password'}
                  value={newToken}
                  onChange={(e) => setNewToken(e.target.value)}
                  placeholder="Token dengan izin edit DNS"
                  required
                  autoComplete="off"
                  className="w-full bg-transparent py-3 font-mono text-sm outline-none"
                />
                <EyeToggle
                  revealed={showToken}
                  onToggle={() => setShowToken((s) => !s)}
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="new-zone"
                className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
              >
                Zone ID
              </label>
              <input
                id="new-zone"
                value={newZone}
                onChange={(e) => setNewZone(e.target.value)}
                placeholder="(opsional) auto-detect dari domain"
                autoComplete="off"
                className="w-full rounded-xl border border-input bg-background/60 px-4 py-3 font-mono text-sm outline-none focus:ring-2 focus:ring-ring"
              />
            </div>

            <p className="flex items-start gap-2 rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2.5 text-xs leading-relaxed text-destructive">
              <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
              Token disimpan di browser ini saja dan hanya dipakai untuk
              mengelola DNS domain tersebut. Pastikan token punya izin
              &quot;Zone → DNS → Edit&quot;.
            </p>

            {formErr && (
              <p className="flex items-center gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                <AlertCircle className="h-4 w-4 shrink-0" aria-hidden />
                {formErr}
              </p>
            )}

            <Button
              type="submit"
              disabled={adding}
              className="h-12 w-full rounded-xl"
            >
              {adding ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : added ? (
                <Check className="h-4 w-4" aria-hidden />
              ) : (
                <Plus className="h-4 w-4" aria-hidden />
              )}
              {added ? 'Domain ditambahkan' : 'Tambah domain'}
            </Button>
          </form>
        </Card>
      </ScrollReveal>

      {/* THEME */}
      <ScrollReveal delay={160}>
        <Card
          icon={Palette}
          title="Tema warna"
          desc="Pilih aksen digital atau aktifkan spektrum RGB."
        >
          {/* live preview chip */}
          <div className="mb-5 flex items-center gap-3 rounded-2xl border border-border bg-background/40 p-3">
            <span
              className="h-12 w-12 shrink-0 rounded-xl ring-2 ring-border"
              style={{ backgroundColor: `oklch(0.6 0.27 ${hue})` }}
              aria-hidden
            />
            <div className="min-w-0">
              <p className="font-heading text-sm font-semibold">
                Warna brand aktif
              </p>
              <p className="font-mono text-xs text-muted-foreground">
                {rgb
                  ? 'Mode RGB (pelangi)'
                  : `hue ${Math.round(hue)}° · ${hueToHex(hue)}`}
              </p>
            </div>
          </div>

          {/* presets */}
          <div className="flex flex-wrap gap-2.5">
            {PRESETS.map((p) => {
              const isActive = !rgb && Math.abs(hue - p.hue) < 1
              return (
                <button
                  key={p.name}
                  type="button"
                  onClick={() => update({ hue: p.hue, rgb: false })}
                  title={p.name}
                  aria-label={`Warna ${p.name}`}
                  aria-pressed={isActive}
                  className={cn(
                    'h-10 w-10 rounded-full ring-2 ring-offset-2 ring-offset-card transition-transform hover:scale-110',
                    isActive ? 'ring-foreground' : 'ring-transparent',
                  )}
                  style={{ backgroundColor: `oklch(0.6 0.27 ${p.hue})` }}
                />
              )
            })}
          </div>

          {/* native RGB color picker */}
          <div className="mt-6 flex items-center justify-between gap-3 rounded-xl border border-border bg-background/40 px-4 py-3">
            <span className="flex items-center gap-2 text-sm">
              <Pipette className="h-4 w-4 text-primary" aria-hidden />
              <span>
                <span className="block font-medium">Pemilih warna (RGB)</span>
                <span className="block text-xs text-muted-foreground">
                  Pilih warna persis sesukamu.
                </span>
              </span>
            </span>
            <input
              type="color"
              aria-label="Pilih warna brand"
              value={hueToHex(hue)}
              disabled={rgb}
              onChange={(e) =>
                update({ hue: hexToHue(e.target.value), rgb: false })
              }
              className="h-11 w-16 cursor-pointer rounded-lg border border-border bg-transparent disabled:opacity-50"
            />
          </div>

          {/* hue slider */}
          <div className="mt-6">
            <div className="mb-2 flex items-center justify-between">
              <label
                htmlFor="hue"
                className="font-mono text-xs uppercase tracking-widest text-muted-foreground"
              >
                Hue kustom
              </label>
              <span className="font-mono text-xs text-primary">
                {rgb ? 'RGB' : `${Math.round(hue)}°`}
              </span>
            </div>
            <input
              id="hue"
              type="range"
              min={0}
              max={360}
              value={hue}
              disabled={rgb}
              onChange={(e) =>
                update({ hue: Number(e.target.value), rgb: false })
              }
              className="h-3 w-full cursor-pointer appearance-none rounded-full bg-primary disabled:opacity-50"
            />
          </div>

          {/* RGB rainbow mode toggle */}
          <button
            type="button"
            onClick={() => update({ rgb: !rgb })}
            className="mt-5 flex w-full items-center justify-between rounded-xl border border-border bg-background/40 px-4 py-3 text-left transition-colors hover:bg-background/70"
          >
            <span>
              <span className="block text-sm font-medium">Mode RGB pelangi</span>
              <span className="block text-xs text-muted-foreground">
                Warna berputar otomatis seperti pelangi.
              </span>
            </span>
            <span
              className={cn(
                'relative h-6 w-11 rounded-full transition-colors',
                rgb ? 'bg-primary' : 'bg-muted',
              )}
            >
              <span
                className={cn(
                  'absolute top-0.5 h-5 w-5 rounded-full bg-background transition-all',
                  rgb ? 'left-[22px]' : 'left-0.5',
                )}
              />
            </span>
          </button>

          <button
            type="button"
            onClick={resetTheme}
            className="mt-4 inline-flex items-center gap-2 text-xs font-medium text-muted-foreground transition-colors hover:text-primary"
          >
            <RotateCcw className="h-3.5 w-3.5" aria-hidden />
            Kembali ke cyan default
          </button>
        </Card>
      </ScrollReveal>

      {/* LOGOUT */}
      <ScrollReveal delay={220}>
        <Button
          type="button"
          variant="secondary"
          onClick={logout}
          className="h-12 w-full rounded-xl"
        >
          <LogOut className="h-4 w-4" aria-hidden />
          Keluar
        </Button>
      </ScrollReveal>
    </div>
  )
}
