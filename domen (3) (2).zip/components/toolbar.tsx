'use client'

import { useEffect, useRef, useState } from 'react'
import { Home, List, Info, Settings } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSettings } from '@/components/settings-provider'

export type View = 'home' | 'list' | 'about' | 'settings'

const items: { id: View; label: string; desc: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', desc: 'Buat subdomain baru', icon: Home },
  { id: 'list', label: 'List', desc: 'Semua subdomain', icon: List },
  { id: 'about', label: 'About', desc: 'Tentang & creator', icon: Info },
  { id: 'settings', label: 'Settings', desc: 'Pengaturan & tema', icon: Settings },
]

/* 2-line minimal menu icon that morphs into an X when open. */
function LineMenuIcon({ open }: { open: boolean }) {
  return (
    <span aria-hidden className="relative grid h-4 w-5 place-items-center">
      <span
        className={cn(
          'absolute left-0 h-[1.5px] w-5 rounded-full bg-current transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]',
          open ? 'translate-y-0 rotate-45' : '-translate-y-[4px] rotate-0',
        )}
      />
      <span
        className={cn(
          'absolute left-0 h-[1.5px] rounded-full bg-current transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]',
          open ? 'w-5 translate-y-0 -rotate-45' : 'w-3.5 translate-y-[4px] rotate-0',
        )}
      />
    </span>
  )
}

export function Toolbar({
  view,
  onChange,
}: {
  view: View
  onChange: (v: View) => void
}) {
  const { domain } = useSettings()
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  // subtle border + blur once scrolled
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // close on outside click / Escape
  useEffect(() => {
    if (!open) return
    function onDoc(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('mousedown', onDoc)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDoc)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  return (
    <header
      className={cn(
        'sticky top-0 z-40 w-full transition-all duration-300',
        scrolled
          ? 'border-b border-border/60 bg-background/80 backdrop-blur-xl'
          : 'border-b border-transparent bg-transparent',
      )}
    >
      <div ref={menuRef} className="relative mx-auto flex h-14 w-full max-w-2xl items-center justify-between px-4">
        {/* BRAND */}
        <button
          type="button"
          onClick={() => onChange('home')}
          className="group flex min-w-0 items-center gap-2.5 rounded-md py-1 pr-2 text-left transition-opacity hover:opacity-80"
          aria-label={`Buka beranda ${domain}`}
        >
          <span
            aria-hidden
            className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border border-primary/30 bg-primary/10 font-heading text-sm font-bold text-primary"
          >
            Z
          </span>
          <span className="min-w-0">
            <span className="block truncate font-heading text-sm font-semibold leading-tight text-foreground">
              IZSUBDO
            </span>
            <span className="hidden truncate font-mono text-[11px] leading-tight text-muted-foreground sm:block">
              {domain}
            </span>
          </span>
        </button>

        {/* DESKTOP NAV — plain text links, underline indicator */}
        <nav aria-label="Navigasi utama" className="hidden items-center gap-1 sm:flex">
          {items.map(({ id, label }) => {
            const isActive = view === id
            return (
              <button
                key={id}
                type="button"
                onClick={() => onChange(id)}
                aria-current={isActive ? 'page' : undefined}
                className={cn(
                  'relative rounded-md px-3 py-1.5 text-sm transition-colors',
                  isActive
                    ? 'font-medium text-foreground'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {label}
                <span
                  aria-hidden
                  className={cn(
                    'absolute inset-x-3 -bottom-px h-px rounded-full bg-primary transition-opacity',
                    isActive ? 'opacity-100' : 'opacity-0',
                  )}
                />
              </button>
            )
          })}
        </nav>

        {/* MOBILE: menu toggle */}
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-haspopup="menu"
          aria-label={open ? 'Tutup menu' : 'Buka menu'}
          className="grid h-9 w-9 place-items-center rounded-md text-foreground transition-colors hover:bg-secondary active:scale-95 sm:hidden"
        >
          <LineMenuIcon open={open} />
        </button>

        {/* MOBILE DROPDOWN */}
        <div
          role="menu"
          aria-label="Menu navigasi"
          className={cn(
            'absolute right-4 top-[calc(100%+0.4rem)] z-50 w-60 origin-top-right overflow-hidden rounded-xl border border-border bg-popover/95 p-1.5 shadow-lg backdrop-blur-xl transition-all duration-200 sm:hidden',
            open
              ? 'pointer-events-auto translate-y-0 scale-100 opacity-100'
              : 'pointer-events-none -translate-y-1 scale-[0.98] opacity-0',
          )}
        >
          {items.map(({ id, label, desc, icon: Icon }, i) => {
            const isActive = view === id
            return (
              <button
                key={id}
                type="button"
                role="menuitem"
                onClick={() => {
                  onChange(id)
                  setOpen(false)
                }}
                style={{ transitionDelay: open ? `${i * 30}ms` : '0ms' }}
                className={cn(
                  'flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-all duration-300',
                  open ? 'translate-x-0 opacity-100' : 'translate-x-2 opacity-0',
                  isActive
                    ? 'bg-secondary text-foreground'
                    : 'text-popover-foreground hover:bg-secondary/60',
                )}
              >
                <Icon
                  className={cn(
                    'h-4 w-4 shrink-0',
                    isActive ? 'text-primary' : 'text-muted-foreground',
                  )}
                  aria-hidden
                />
                <span className="min-w-0">
                  <span className="block text-sm font-medium leading-tight">{label}</span>
                  <span className="block truncate text-xs leading-tight text-muted-foreground">
                    {desc}
                  </span>
                </span>
                {isActive && (
                  <span
                    aria-hidden
                    className="ml-auto h-1.5 w-1.5 shrink-0 rounded-full bg-primary"
                  />
                )}
              </button>
            )
          })}
        </div>
      </div>
    </header>
  )
}
