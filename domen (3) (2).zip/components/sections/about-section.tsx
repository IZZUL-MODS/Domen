'use client'

import {
  Heart,
  Code2,
  Cloud,
  Rocket,
  Sparkles,
  GitBranch,
  Share2,
  Play,
} from 'lucide-react'
import { ScrollReveal } from '@/components/scroll-reveal'
import { FaGithub } from 'react-icons/fa'; // Mengambil ikon GitHub dari FontAwesome (react-icons/fa)

const timeline = [
  {
    icon: Rocket,
    title: 'Asal usul IZSUBDO',
    body: 'IZSUBDO berawal dari keinginan sederhana: bikin alamat web yang singkat dan mudah diingat tanpa perlu membeli domain sendiri. Akhirnya, izsubdo.my.id dibuka supaya siapa pun bisa punya subdomain gratis.',
  },
  {
    icon: Cloud,
    title: 'Cepat dan tetap stabil',
    body: 'Semua subdomain dikelola melalui Cloudflare DNS. Hasilnya, perubahan record bisa diproses dengan cepat dan alamat yang dibuat tetap nyaman digunakan untuk berbagai kebutuhan.',
  },
  {
    icon: Code2,
    title: 'Dibuat untuk mudah digunakan',
    body: 'Tampilannya dibuat sederhana agar siapa pun bisa langsung mengerti. Di baliknya, IZSUBDO memakai Next.js, React, Tailwind CSS, dan TypeScript supaya tetap ringan dan mudah dikembangkan.',
  },
]

/* ---- Brand SVG logos (4) ---- */
/* ---- Brand SVG logos (4) — versi berwarna realistis ---- */
function NextLogo({ className = '' }) {
  // Lingkaran hitam, panah putih. Dibalik otomatis saat dark mode.
  return (
    <svg viewBox="0 0 128 128" className={`${className} dark:invert`} aria-hidden>
      <circle cx="64" cy="64" r="64" fill="#000" />
      <path
        fill="#fff"
        d="M106 112 49 38v52h-9V37h11l55 70a64 64 0 0 1-0 5zM83 38h9v40l-9-12z"
      />
    </svg>
  )
}

function ReactLogo({ className = '' }) {
  // Cyan khas React (#61DAFB)
  return (
    <svg
      viewBox="-11.5 -10.23174 23 20.46348"
      className={className}
      aria-hidden
    >
      <circle r="2.05" fill="#61DAFB" />
      <g stroke="#61DAFB" strokeWidth="1" fill="none">
        <ellipse rx="11" ry="4.2" />
        <ellipse rx="11" ry="4.2" transform="rotate(60)" />
        <ellipse rx="11" ry="4.2" transform="rotate(120)" />
      </g>
    </svg>
  )
}

function TailwindLogo({ className = '' }) {
  // Cyan gradient khas Tailwind (#38BDF8 -> #0EA5E9)
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden>
      <defs>
        <linearGradient id="tw-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#38BDF8" />
          <stop offset="100%" stopColor="#0EA5E9" />
        </linearGradient>
      </defs>
      <path
        fill="url(#tw-grad)"
        d="M24 9.6c-6.4 0-10.4 3.2-12 9.6 2.4-3.2 5.2-4.4 8.4-3.6 1.83.46 3.13 1.78 4.58 3.24C27.33 21.24 30.06 24 36 24c6.4 0 10.4-3.2 12-9.6-2.4 3.2-5.2 4.4-8.4 3.6-1.83-.46-3.13-1.78-4.58-3.24C32.67 12.36 29.94 9.6 24 9.6zM12 24c-6.4 0-10.4 3.2-12 9.6 2.4-3.2 5.2-4.4 8.4-3.6 1.83.46 3.13 1.78 4.58 3.24C15.33 35.64 18.06 38.4 24 38.4c6.4 0 10.4-3.2 12-9.6-2.4 3.2-5.2 4.4-8.4 3.6-1.83-.46-3.13-1.78-4.58-3.24C20.67 26.76 17.94 24 12 24z"
      />
    </svg>
  )
}

function TypeScriptLogo({ className = '' }) {
  // Biru khas TypeScript (#3178C6) dengan huruf "TS" putih
  return (
    <svg viewBox="0 0 128 128" className={className} aria-hidden>
      <rect width="128" height="128" rx="14" fill="#3178C6" />
      <path
        fill="#fff"
        d="M73 65v-10H37v10h12v37h12V65zM83 102c3 1.7 7 3 12 3 10 0 17-5 17-14 0-8-4.5-11-13-14-5-1.8-7-2.7-7-5 0-1.8 1.6-3 4.6-3 3.4 0 6.4 1.3 9 3l5-7c-3.4-2.7-7.6-4-13-4-9 0-15 5-15 13 0 8 5 11 13 14 5 1.8 6.6 2.8 6.6 5 0 2-2 3.3-5.4 3.3-4 0-7.4-1.6-10-3.7z"
      />
    </svg>
  )
}


const stack = [
  { name: 'Next.js', Logo: NextLogo },
  { name: 'React', Logo: ReactLogo },
  { name: 'Tailwind', Logo: TailwindLogo },
  { name: 'TypeScript', Logo: TypeScriptLogo },
]

/* ---- Social buttons ---- */
const socials = [
  {
    name: 'GitHub',
    href: 'https://github.com/IZZUL-MODS',
    Icon: FaGithub,
    hover: 'hover:shadow-[0_0_30px_-4px] hover:shadow-foreground/40',
    ring: 'group-hover:ring-foreground/50',
    action: 'link',
  },
  {
    name: 'YouTube',
    href: 'https://youtube.com/@izzul_maker?si=SGYW6i3Xs6ZnbmG-',
    Icon: Play,
    hover: 'hover:shadow-[0_0_30px_-4px] hover:shadow-red-500/60',
    ring: 'group-hover:ring-red-500/60',
    action: 'link',
  },
    {
    name: 'Share',
    action: 'share',
    Icon: Share2,
    hover: 'hover:shadow-[0_0_30px_-4px] hover:shadow-blue-500/60',
    ring: 'group-hover:ring-blue-500/60',
  },
]

export function AboutSection() {
  const handleShare = async () => {
    const shareData = {
      title: 'IZSUBDO - Free Web Subdomain',
      text: 'Gunakan IZSUBDO: Gratis, tanpa iklan, bisa custom nama subdo, tersedia 3 subdomain, dan cocok untuk bikin panel!!',
      url: typeof window !== 'undefined' ? window.location.origin : 'https://izsubdo.my.id',
    }

    try {
      if (navigator.share) {
        await navigator.share(shareData)
      } else {
        await navigator.clipboard.writeText(shareData.url)
        alert('Link disalin ke clipboard!')
      }
    } catch (err) {
      console.error('Error sharing:', err)
    }
  }

  return (
    <section className="mx-auto w-full max-w-3xl px-4 pb-24 pt-16 sm:pt-24">
      <ScrollReveal className="text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs uppercase tracking-[0.3em] text-primary">
          <Sparkles className="h-3.5 w-3.5" aria-hidden />
          Tentang
        </span>
        <h1 className="mt-5 font-heading text-4xl font-bold tracking-tight text-balance sm:text-6xl">
          Asal usul{' '}
          <span className="font-display italic font-medium text-primary text-glow">
            IZSUBDO
          </span>
        </h1>
        <p className="mx-auto mt-5 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
          IZSUBDO dibuat untuk kamu yang ingin punya alamat web sendiri tanpa
          proses yang rumit. Pilih nama subdomain, arahkan ke tujuanmu, lalu
          gunakan sesuai kebutuhan.
        </p>
      </ScrollReveal>

      {/* timeline */}
      <div className="relative mt-16 flex flex-col gap-5 before:absolute before:left-[27px] before:top-4 before:bottom-4 before:w-px before:bg-primary/40">
        {timeline.map((t, i) => (
          <ScrollReveal key={t.title} delay={i * 120}>
            <div className="group relative flex gap-5 rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-xl hover:shadow-primary/10">
              <div className="relative z-10 flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary/15 ring-1 ring-primary/20 transition-all duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
                <t.icon className="h-6 w-6 text-primary transition-colors group-hover:text-primary-foreground" aria-hidden />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-primary/70">
                    0{i + 1}
                  </span>
                  <h2 className="font-heading text-lg font-semibold">
                    {t.title}
                  </h2>
                </div>
                <p className="mt-1.5 leading-relaxed text-muted-foreground">
                  {t.body}
                </p>
              </div>
            </div>
          </ScrollReveal>
        ))}
      </div>

      {/* tech stack (4 logos) */}
      <ScrollReveal delay={120} className="mt-12">
        <div className="rounded-3xl border border-border bg-card/60 p-7 backdrop-blur-md">
          <p className="text-center font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground">
            Dibangun Izzul dengan
          </p>
          <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {stack.map(({ name, Logo }) => (
              <div
                key={name}
                className="group flex flex-col items-center gap-3 rounded-2xl border border-border/60 bg-background/40 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/15"
              >
                <Logo className="h-10 w-10 text-foreground transition-transform duration-300 group-hover:scale-110 group-hover:text-primary" />
                <span className="font-heading text-sm font-semibold">
                  {name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </ScrollReveal>

      {/* creator card */}
      <ScrollReveal delay={150} className="mt-10">
        <div className="box-glow relative overflow-hidden rounded-3xl border border-border bg-card/70 p-8 text-center backdrop-blur-xl">
          <div className="pointer-events-none absolute inset-0 aurora opacity-40" />
          <div className="relative">
            <div
              className="group relative mx-auto grid h-20 w-20 place-items-center"
              aria-label="Logo Z Izzul"
            >
              <span className="absolute inset-0 rounded-2xl border border-primary/30 bg-background/70 shadow-lg shadow-primary/30 backdrop-blur-md transition-transform duration-500 group-hover:rotate-6 group-hover:scale-105" />
              <span className="absolute inset-2 animate-[spin_8s_linear_infinite] rounded-xl border border-primary/60 motion-reduce:animate-none" />
              <span className="absolute -inset-1 animate-pulse rounded-3xl border border-primary/20 motion-reduce:animate-none" />
              <span className="absolute left-1/2 top-0 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary shadow-md shadow-primary" />
              <svg
                viewBox="0 0 48 48"
                className="relative h-11 w-11 overflow-visible text-primary drop-shadow-[0_0_10px_var(--glow)] transition-transform duration-300 group-hover:-rotate-6 group-hover:scale-110"
                aria-hidden="true"
              >
                <defs>
                  <linearGradient id="z-shine" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="var(--foreground)" stopOpacity="0.9" />
                    <stop offset="100%" stopColor="var(--foreground)" stopOpacity="0" />
                  </linearGradient>
                </defs>
                {/* Bayangan belakang - efek 3D layer */}
                <path
                  d="M6 6h36L22.5 18.5H35L10 42l7.5-14.5H6L25 14H6z"
                  fill="currentColor"
                  opacity="0.3"
                  transform="translate(2.5 2.5)"
                />
                {/* Z utama - bentuk petir tegas */}
                <path
                  d="M6 6h36L22.5 18.5H35L10 42l7.5-14.5H6L25 14H6z"
                  fill="currentColor"
                  stroke="currentColor"
                  strokeWidth="1"
                  strokeLinejoin="round"
                />
                {/* Kilau terang di bagian atas */}
                <path
                  d="M7.5 7.5h31l-3 2.5H9z"
                  fill="url(#z-shine)"
                  opacity="0.9"
                />
                {/* Partikel energi */}
                <circle cx="44" cy="9" r="1.5" fill="currentColor" opacity="0.9" />
                <circle cx="4" cy="40" r="1.2" fill="currentColor" opacity="0.7" />
                <circle cx="40" cy="32" r="1" fill="currentColor" opacity="0.5" />
              </svg>
            </div>
            <h2 className="mt-5 font-heading text-2xl font-bold">
              Dibuat oleh{' '}
              <span className="text-primary text-glow">Izzul</span>
            </h2>
            <p className="mx-auto mt-2 max-w-md leading-relaxed text-muted-foreground">
              Saya membuat IZSUBDO sebagai proyek sederhana yang bisa dipakai
              banyak orang. Masukan dan saran selalu terbuka supaya layanan ini
              bisa terus dibenahi dan makin nyaman digunakan.
            </p>

            {/* social buttons */}
            <div className="mt-7 flex items-center justify-center gap-4">
              {socials.map(({ name, href, Icon, hover, ring, action }) => {
                if (action === 'share') {
                  return (
                    <button
                      key={name}
                      onClick={handleShare}
                      aria-label={name}
                      className={`group relative grid h-12 w-12 place-items-center rounded-2xl border border-border bg-background/60 text-foreground transition-all duration-300 hover:-translate-y-1 hover:text-primary ${hover}`}
                    >
                      <span
                        className={`pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-transparent transition-all duration-300 ${ring}`}
                      />
                      <Icon className="h-5 w-5 transition-transform duration-300 group-hover:scale-110" aria-hidden />
                    </button>
                  )
                }
                return (
                  <a
                    key={name}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={name}
                    className={`group relative grid h-12 w-12 place-items-center rounded-2xl border border-border bg-background/60 text-foreground transition-all duration-300 hover:-translate-y-1 hover:text-primary ${hover}`}
                  >
                    <span
                      className={`pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-transparent transition-all duration-300 ${ring}`}
                    />
                    <Icon className="h-5 w-5 transition-transform duration-300 group-hover:scale-110" aria-hidden />
                  </a>
                )
              })}
            </div>

            {/* copyright */}
            <div className="mt-6 border-t border-border/60 pt-5">
              <p className="font-mono text-xs text-muted-foreground">
                © {new Date().getFullYear()}{' '}
                <span className="font-semibold text-foreground">IZSUBDO</span> All rights reserved.                             </p>
            </div>
          </div>
        </div>
      </ScrollReveal>
    </section>
  )
}
