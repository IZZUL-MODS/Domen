import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import {
  Outfit,
  Space_Grotesk,
  Playfair_Display,
  JetBrains_Mono,
  Unbounded,
} from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/components/theme-provider'
import { SettingsProvider } from '@/components/settings-provider'

const outfit = Outfit({ variable: '--font-outfit', subsets: ['latin'] })
const spaceGrotesk = Space_Grotesk({
  variable: '--font-space-grotesk',
  subsets: ['latin'],
})
const playfair = Playfair_Display({
  variable: '--font-playfair',
  subsets: ['latin'],
})
const jetbrains = JetBrains_Mono({
  variable: '--font-jetbrains',
  subsets: ['latin'],
})
// Font display "no pasaran" untuk wordmark logo
const unbounded = Unbounded({
  variable: '--font-display',
  subsets: ['latin'],
  weight: ['600', '700', '800'],
})

export const metadata: Metadata = {
  title: 'Zulzz Subdomain · zulzz.my.id',
  description:
    'Buat subdomain keren-mu sendiri di zulzz.my.id. Cepat, gratis, dan bertenaga Cloudflare.',
  generator: 'v0.app',
}

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#faf5ff' },
    { media: '(prefers-color-scheme: dark)', color: '#070109' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="id"
      className={`${outfit.variable} ${spaceGrotesk.variable} ${playfair.variable} ${jetbrains.variable} ${unbounded.variable} bg-background`}
      suppressHydrationWarning
    >
      <body className="font-sans antialiased">
        <SettingsProvider>
          <ThemeProvider>{children}</ThemeProvider>
        </SettingsProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
