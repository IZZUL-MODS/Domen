'use client'

import { useEffect, useRef, useState } from 'react'
import { Sun, Moon } from 'lucide-react'
import { useTheme } from '@/components/theme-provider'
import { cn } from '@/lib/utils'

const SIZE = 64
const DRAG_THRESHOLD = 6

export function DraggableThemeLogo() {
  const { theme, toggleTheme } = useTheme()
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null)
  const [dragging, setDragging] = useState(false)
  const drag = useRef({
    active: false,
    moved: false,
    startX: 0,
    startY: 0,
    offX: 0,
    offY: 0,
  })

  // initialize bottom-center once we know the viewport
  useEffect(() => {
    const init = () => {
      setPos((p) =>
        p
          ? p
          : {
              x: window.innerWidth / 2 - SIZE / 2,
              y: window.innerHeight - SIZE - 28,
            },
      )
    }
    init()
    window.addEventListener('resize', clampToViewport)
    return () => window.removeEventListener('resize', clampToViewport)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const clampToViewport = () => {
    setPos((p) => {
      if (!p) return p
      return {
        x: Math.min(Math.max(8, p.x), window.innerWidth - SIZE - 8),
        y: Math.min(Math.max(8, p.y), window.innerHeight - SIZE - 8),
      }
    })
  }

  const onPointerDown = (e: React.PointerEvent) => {
    if (!pos) return
    ;(e.target as HTMLElement).setPointerCapture(e.pointerId)
    drag.current = {
      active: true,
      moved: false,
      startX: e.clientX,
      startY: e.clientY,
      offX: e.clientX - pos.x,
      offY: e.clientY - pos.y,
    }
    setDragging(true)
  }

  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag.current.active) return
    const dx = e.clientX - drag.current.startX
    const dy = e.clientY - drag.current.startY
    if (Math.abs(dx) > DRAG_THRESHOLD || Math.abs(dy) > DRAG_THRESHOLD) {
      drag.current.moved = true
    }
    setPos({
      x: Math.min(
        Math.max(8, e.clientX - drag.current.offX),
        window.innerWidth - SIZE - 8,
      ),
      y: Math.min(
        Math.max(8, e.clientY - drag.current.offY),
        window.innerHeight - SIZE - 8,
      ),
    })
  }

  const onPointerUp = () => {
    const wasTap = drag.current.active && !drag.current.moved
    drag.current.active = false
    setDragging(false)
    if (wasTap) toggleTheme()
  }

  if (!pos) return null

  // The logo shows the mode you will switch TO when pressed.
  const willBeNight = theme === 'day'

  return (
    <button
      type="button"
      aria-label={
        willBeNight ? 'Aktifkan mode malam' : 'Aktifkan mode siang'
      }
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      style={{ left: pos.x, top: pos.y, width: SIZE, height: SIZE }}
      className={cn(
        'fixed z-50 flex touch-none select-none items-center justify-center rounded-full border border-border bg-popover/80 backdrop-blur-xl box-glow',
        'transition-[box-shadow,transform] duration-300',
        dragging ? 'scale-110 cursor-grabbing' : 'cursor-grab animate-float-slow hover:scale-105',
      )}
    >
      <span className="pointer-events-none flex flex-col items-center justify-center gap-0.5">
        {willBeNight ? (
          <Moon className="h-6 w-6 text-primary" aria-hidden />
        ) : (
          <Sun className="h-6 w-6 text-primary" aria-hidden />
        )}
        <span className="font-mono text-[8px] font-semibold uppercase tracking-widest text-muted-foreground">
          {willBeNight ? 'malam' : 'siang'}
        </span>
      </span>
    </button>
  )
}
