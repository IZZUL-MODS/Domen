'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'

export const DEFAULT_DOMAIN = 'zulzz.my.id'
export const DEFAULT_HUE = 300 // purple

// Hardcoded gate credentials (simple admin lock, not hardened security)
const ADMIN_USER = 'izzul'
const ADMIN_PASS = 'IZZUL@198'

const SETTINGS_KEY = 'zulzz-settings'
const AUTH_KEY = 'zulzz-auth'

type PersistedSettings = {
  domain: string
  token: string
  zoneId: string
  hue: number
  rgb: boolean
}

const defaults: PersistedSettings = {
  domain: DEFAULT_DOMAIN,
  token: '',
  zoneId: '',
  hue: DEFAULT_HUE,
  rgb: false,
}

type SettingsContextValue = PersistedSettings & {
  ready: boolean
  authed: boolean
  // config headers for talking to /api/subdomains
  configHeaders: () => Record<string, string>
  update: (patch: Partial<PersistedSettings>) => void
  resetTheme: () => void
  login: (user: string, pass: string, remember: boolean) => boolean
  logout: () => void
}

const SettingsContext = createContext<SettingsContextValue | null>(null)

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<PersistedSettings>(defaults)
  const [authed, setAuthed] = useState(false)
  const [ready, setReady] = useState(false)

  // hydrate from storage
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY)
      if (raw) setSettings({ ...defaults, ...JSON.parse(raw) })
    } catch {
      /* ignore */
    }
    const remembered = localStorage.getItem(AUTH_KEY) === '1'
    const sessionAuthed = sessionStorage.getItem(AUTH_KEY) === '1'
    setAuthed(remembered || sessionAuthed)
    setReady(true)
  }, [])

  // persist + apply theme to <html>
  useEffect(() => {
    if (!ready) return
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings))
    } catch {
      /* ignore */
    }
    const root = document.documentElement
    if (settings.rgb) {
      root.classList.add('rgb-mode')
      root.style.removeProperty('--h')
    } else {
      root.classList.remove('rgb-mode')
      root.style.setProperty('--h', String(settings.hue))
    }
  }, [settings, ready])

  const update = useCallback((patch: Partial<PersistedSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }))
  }, [])

  const resetTheme = useCallback(() => {
    setSettings((prev) => ({ ...prev, hue: DEFAULT_HUE, rgb: false }))
  }, [])

  const login = useCallback(
    (user: string, pass: string, remember: boolean) => {
      const ok = user.trim() === ADMIN_USER && pass === ADMIN_PASS
      if (ok) {
        setAuthed(true)
        if (remember) {
          localStorage.setItem(AUTH_KEY, '1')
          sessionStorage.removeItem(AUTH_KEY)
        } else {
          sessionStorage.setItem(AUTH_KEY, '1')
          localStorage.removeItem(AUTH_KEY)
        }
      }
      return ok
    },
    [],
  )

  const logout = useCallback(() => {
    setAuthed(false)
    localStorage.removeItem(AUTH_KEY)
    sessionStorage.removeItem(AUTH_KEY)
  }, [])

  const configHeaders = useCallback((): Record<string, string> => {
    const h: Record<string, string> = {
      'x-cf-domain': settings.domain || DEFAULT_DOMAIN,
    }
    if (settings.token.trim()) h['x-cf-token'] = settings.token.trim()
    if (settings.zoneId.trim()) h['x-cf-zone'] = settings.zoneId.trim()
    return h
  }, [settings.domain, settings.token, settings.zoneId])

  const value = useMemo<SettingsContextValue>(
    () => ({
      ...settings,
      ready,
      authed,
      configHeaders,
      update,
      resetTheme,
      login,
      logout,
    }),
    [settings, ready, authed, configHeaders, update, resetTheme, login, logout],
  )

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const ctx = useContext(SettingsContext)
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider')
  return ctx
}
