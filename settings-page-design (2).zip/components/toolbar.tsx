'use client'

import { useEffect, useRef, useState } from 'react'
import { Home, List, Info, Settings, Globe } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSettings } from '@/components/settings-provider'

export type View = 'home' | 'list' | 'about' | 'settings'

const items: { id: View; label: string; desc: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', desc: 'Buat subdomain baru', icon: Home },
  { id: 'list', label: 'List', desc: 'Semua subdomain', icon: List },
  { id: 'about', label: 'About', desc: 'Tentang & creator', icon: Info },
  { id: 'settings', label: 'Settings', desc: 'Pengaturan & tema', icon: Settings },
]

/* Custom 3-line "-" menu icon that morphs into an X when open. */
function LineMenuIcon({ open }: { open: boolean }) {
  return (
    <span aria-hidden className="relative grid h-5 w-6 place-items-center">
      <span
        className={cn(
          'absolute left-0 h-[2.5px] w-6 rounded-full bg-current transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]',
          open ? 'translate-y-0 rotate-45' : '-translate-y-[7px] rotate-0',
        )}
      />
      <span
        className={cn(
          'absolute left-0 h-[2.5px] w-6 rounded-full bg-current transition-all duration-200',
          open ? 'scale-x-0 opacity-0' : 'scale-x-100 opacity-100',
        )}
      />
      <span
        className={cn(
          'absolute left-0 h-[2.5px] w-6 rounded-full bg-current transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]',
          open ? 'translate-y-0 -rotate-45' : 'translate-y-[7px] rotate-0',
        )}
      />
    </span>
  )
}

export function Toolbar({
  view,
  onChange,
}: {
  view: View
  onChange: (v: View) => void
}) {
  const { domain } = useSettings()
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  // domain -> "name" + ".tld" for the wordmark
  const dot = domain.indexOf('.')
  const head = dot > 0 ? domain.slice(0, dot) : domain
  const tail = dot > 0 ? domain.slice(dot) : ''

  // subtle condense on scroll
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // close on outside click / Escape
  useEffect(() => {
    if (!open) return
    function onDoc(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('mousedown', onDoc)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDoc)
      document.removeEventListener('keydown', onKey)
    }
  }, [open])

  const active = items.find((i) => i.id === view)

  return (
    <header className="sticky top-0 z-40 flex justify-center px-4 pt-4">
      <div ref={menuRef} className="relative w-full max-w-2xl">
        <nav
          aria-label="Navigasi utama"
          className={cn(
            'box-glow flex items-center justify-between gap-3 rounded-full border border-primary-foreground/15 bg-primary text-primary-foreground backdrop-blur-xl transition-all duration-300',
            scrolled ? 'px-2 py-1.5 shadow-2xl' : 'px-2.5 py-2.5',
          )}
        >
          {/* LEFT: iconic website logo */}
          {/* LEFT: domain icon + wordmark */}
<button
  type="button"
  onClick={() => onChange('home')}
  className="group flex items-center gap-2.5 rounded-full px-1.5 py-1 transition-transform hover:scale-[1.02] active:scale-95"
  aria-label="namamu coy — beranda"
>
  <span
    aria-hidden
    className={cn(
      'relative grid place-items-center rounded-2xl bg-primary-foreground text-primary shadow-lg ring-1 ring-primary-foreground/30 transition-all duration-300',
      scrolled ? 'h-8 w-8' : 'h-9 w-9',
    )}
  >
    <span className="absolute inset-[-3px] rounded-2xl border border-dashed border-primary-foreground/40 opacity-0 transition-opacity duration-300 group-hover:opacity-100 animate-spin-slow" />
    <Globe className={cn('transition-all', scrolled ? 'h-4 w-4' : 'h-5 w-5')} aria-hidden />
  </span>

  <span className="hidden select-none font-display text-base font-extrabold tracking-tight sm:inline">
    namamu
    <span className="ml-1 font-heading text-sm font-semibold italic text-primary-foreground/70">
      coy
    </span>
  </span>
</button>


          {/* RIGHT: 3-line menu button (morphs to X) */}
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-haspopup="menu"
            aria-label={open ? 'Tutup menu' : 'Buka menu'}
            className={cn(
              'flex items-center gap-2.5 rounded-full px-4 py-2 font-heading text-sm font-semibold transition-colors',
              'bg-primary-foreground/15 hover:bg-primary-foreground/25 active:scale-95',
            )}
          >
            <LineMenuIcon open={open} />
            <span className="hidden sm:inline">{active?.label ?? 'Menu'}</span>
          </button>
        </nav>

        {/* DROPDOWN MENU */}
        <div
          role="menu"
          aria-label="Menu navigasi"
          className={cn(
            'absolute right-0 top-[calc(100%+0.6rem)] z-50 w-72 origin-top-right overflow-hidden rounded-3xl border border-border bg-popover/95 p-2 shadow-2xl shadow-primary/25 backdrop-blur-xl transition-all duration-200',
            open
              ? 'pointer-events-auto translate-y-0 scale-100 opacity-100'
              : 'pointer-events-none -translate-y-2 scale-95 opacity-0',
          )}
        >
          {items.map(({ id, label, desc, icon: Icon }, i) => {
            const isActive = view === id
            return (
              <button
                key={id}
                type="button"
                role="menuitem"
                onClick={() => {
                  onChange(id)
                  setOpen(false)
                }}
                style={{ transitionDelay: open ? `${i * 40}ms` : '0ms' }}
                className={cn(
                  'flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left transition-all duration-300',
                  open ? 'translate-x-0 opacity-100' : 'translate-x-3 opacity-0',
                  isActive
                    ? 'bg-primary text-primary-foreground'
                    : 'text-popover-foreground hover:bg-secondary',
                )}
              >
                <span
                  className={cn(
                    'grid h-9 w-9 shrink-0 place-items-center rounded-xl',
                    isActive
                      ? 'bg-primary-foreground/20'
                      : 'bg-secondary text-primary',
                  )}
                >
                  <Icon className="h-4 w-4" aria-hidden />
                </span>
                <span className="min-w-0">
                  <span className="block font-heading text-sm font-semibold">
                    {label}
                  </span>
                  <span
                    className={cn(
                      'block truncate text-xs',
                      isActive
                        ? 'text-primary-foreground/80'
                        : 'text-muted-foreground',
                    )}
                  >
                    {desc}
                  </span>
                </span>
              </button>
            )
          })}
        </div>
      </div>
    </header>
  )
}
