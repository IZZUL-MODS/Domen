'use client'

import { useState } from 'react'
import { useSWRConfig } from 'swr'
import { Sparkles, Globe, Zap, ShieldCheck, Loader2, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ScrollReveal } from '@/components/scroll-reveal'
import { useSettings } from '@/components/settings-provider'
import { cn } from '@/lib/utils'

const TYPES = ['A', 'AAAA', 'CNAME', 'TXT'] as const
type RecordType = (typeof TYPES)[number]

const placeholders: Record<RecordType, string> = {
  A: '76.76.21.21',
  AAAA: '2606:4700:3033::ac43:9b8a',
  CNAME: 'cname.vercel-dns.com',
  TXT: 'v=spf1 include:_spf.google.com ~all',
}

export function HomeSection() {
  const { mutate } = useSWRConfig()
  const { domain: ROOT } = useSettings()
  const [subdomain, setSubdomain] = useState('')
  const [type, setType] = useState<RecordType>('CNAME')
  const [content, setContent] = useState('')
  const [proxied, setProxied] = useState(true)
  const [status, setStatus] = useState<'idle' | 'loading' | 'ok' | 'error'>(
    'idle',
  )
  const [message, setMessage] = useState('')

  const supportsProxy = type === 'A' || type === 'AAAA' || type === 'CNAME'

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setStatus('loading')
    setMessage('')
    try {
      const res = await fetch('/api/subdomains', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subdomain, type, content, proxied }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Gagal membuat subdomain')
      setStatus('ok')
      setMessage(`${subdomain}.${ROOT} berhasil dibuat!`)
      setSubdomain('')
      setContent('')
      mutate('/api/subdomains')
    } catch (err) {
      setStatus('error')
      setMessage(err instanceof Error ? err.message : 'Terjadi kesalahan')
    }
  }

  return (
    <section className="relative mx-auto w-full max-w-3xl px-4 pb-24 pt-16 sm:pt-24">
      {/* HERO */}
      <ScrollReveal className="text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-4 py-1.5 font-mono text-xs font-medium tracking-wide text-secondary-foreground">
          <Sparkles className="h-3.5 w-3.5 text-primary" aria-hidden />
          Powered by Cloudflare
        </span>
        <h1 className="mt-6 font-heading text-5xl font-bold leading-[1.05] tracking-tight text-balance sm:text-7xl">
          Buat{' '}
          <span className="text-primary text-glow">subdomain</span>
          <br />
          <span className="font-display italic font-medium text-foreground/90">
            super keren
          </span>{' '}
          dalam sekejap
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
          Klaim alamat impianmu di{' '}
          <span className="font-mono text-primary">{ROOT}</span> dan arahkan ke
          mana pun yang kamu mau. Gratis, instan, dan tanpa ribet.
        </p>
      </ScrollReveal>

      {/* CREATE CARD */}
      <ScrollReveal delay={120} className="mt-12">
        <form
          onSubmit={handleSubmit}
          className="box-glow rounded-3xl border border-border bg-card/70 p-6 backdrop-blur-xl sm:p-8"
        >
          <h2 className="font-heading text-lg font-semibold">
            Buat subdomain baru
          </h2>

          {/* subdomain input */}
          <div className="mt-5">
            <label
              htmlFor="sub"
              className="mb-2 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
            >
              Nama subdomain
            </label>
            <div className="flex items-center overflow-hidden rounded-xl border border-input bg-background/60 focus-within:ring-2 focus-within:ring-ring">
              <input
                id="sub"
                value={subdomain}
                onChange={(e) => setSubdomain(e.target.value)}
                placeholder="aku"
                required
                autoComplete="off"
                className="w-full bg-transparent px-4 py-3 font-mono text-base outline-none placeholder:text-muted-foreground/60"
              />
              <span className="whitespace-nowrap border-l border-border bg-secondary/60 px-4 py-3 font-mono text-sm text-muted-foreground">
                .{ROOT}
              </span>
            </div>
          </div>

          {/* type selector */}
          <div className="mt-5">
            <span className="mb-2 block font-mono text-xs uppercase tracking-widest text-muted-foreground">
              Tipe record
            </span>
            <div className="flex flex-wrap gap-2">
              {TYPES.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={cn(
                    'rounded-lg border px-4 py-2 font-mono text-sm font-medium transition-all',
                    type === t
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-border bg-background/60 text-muted-foreground hover:border-primary/50 hover:text-foreground',
                  )}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* content */}
          <div className="mt-5">
            <label
              htmlFor="content"
              className="mb-2 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
            >
              {type === 'TXT' ? 'Isi teks' : 'Mengarah ke'}
            </label>
            <input
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={placeholders[type]}
              required
              autoComplete="off"
              className="w-full rounded-xl border border-input bg-background/60 px-4 py-3 font-mono text-base outline-none placeholder:text-muted-foreground/60 focus:ring-2 focus:ring-ring"
            />
          </div>

          {/* proxy toggle */}
          {supportsProxy && (
            <button
              type="button"
              onClick={() => setProxied((p) => !p)}
              className="mt-5 flex w-full items-center justify-between rounded-xl border border-border bg-background/40 px-4 py-3 text-left transition-colors hover:bg-background/70"
            >
              <span className="flex items-center gap-3">
                <ShieldCheck className="h-5 w-5 text-primary" aria-hidden />
                <span>
                  <span className="block text-sm font-medium">
                    Proxy Cloudflare
                  </span>
                  <span className="block text-xs text-muted-foreground">
                    Sembunyikan IP & aktifkan CDN
                  </span>
                </span>
              </span>
              <span
                className={cn(
                  'relative h-6 w-11 rounded-full transition-colors',
                  proxied ? 'bg-primary' : 'bg-muted',
                )}
              >
                <span
                  className={cn(
                    'absolute top-0.5 h-5 w-5 rounded-full bg-background transition-all',
                    proxied ? 'left-[22px]' : 'left-0.5',
                  )}
                />
              </span>
            </button>
          )}

          <Button
            type="submit"
            disabled={status === 'loading'}
            className="mt-6 h-12 w-full rounded-xl font-heading text-base font-semibold"
          >
            {status === 'loading' ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" aria-hidden />
                Membuat...
              </>
            ) : (
              <>
                <Zap className="h-5 w-5" aria-hidden />
                Buat Subdomain
              </>
            )}
          </Button>

          {message && (
            <p
              className={cn(
                'mt-4 flex items-center gap-2 rounded-lg px-4 py-3 text-sm',
                status === 'ok'
                  ? 'bg-primary/15 text-primary'
                  : 'bg-destructive/15 text-destructive',
              )}
            >
              {status === 'ok' && <Check className="h-4 w-4" aria-hidden />}
              {message}
            </p>
          )}
        </form>
      </ScrollReveal>

      {/* FEATURE STRIP */}
      <div className="mt-16 grid gap-4 sm:grid-cols-3">
        {[
          {
            icon: Zap,
            title: 'Instan',
            desc: 'Aktif dalam hitungan detik via Cloudflare DNS.',
          },
          {
            icon: Globe,
            title: 'Fleksibel',
            desc: 'Dukung A, AAAA, CNAME, hingga TXT record.',
          },
          {
            icon: ShieldCheck,
            title: 'Aman',
            desc: 'Proteksi & proxy bawaan Cloudflare.',
          },
        ].map((f, i) => (
          <ScrollReveal key={f.title} delay={i * 100}>
            <div className="h-full rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-md transition-transform hover:-translate-y-1">
              <f.icon className="h-7 w-7 text-primary" aria-hidden />
              <h3 className="mt-4 font-heading text-base font-semibold">
                {f.title}
              </h3>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                {f.desc}
              </p>
            </div>
          </ScrollReveal>
        ))}
      </div>
    </section>
  )
}
