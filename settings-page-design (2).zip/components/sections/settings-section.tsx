'use client'

import { useState } from 'react'
import {
  Lock,
  User,
  LogOut,
  Globe,
  KeyRound,
  Palette,
  Check,
  AlertCircle,
  ShieldAlert,
  RotateCcw,
  Sparkles,
  Pipette,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ScrollReveal } from '@/components/scroll-reveal'
import { EyeToggle } from '@/components/eye-toggle'
import { useSettings, DEFAULT_DOMAIN } from '@/components/settings-provider'
import { cn } from '@/lib/utils'

const PRESETS: { name: string; hue: number }[] = [
  { name: 'Ungu', hue: 300 },
  { name: 'Magenta', hue: 340 },
  { name: 'Merah', hue: 25 },
  { name: 'Oranye', hue: 60 },
  { name: 'Hijau', hue: 150 },
  { name: 'Cyan', hue: 200 },
  { name: 'Biru', hue: 260 },
  { name: 'Pink', hue: 360 },
]

/* Convert a hex color (#rrggbb) into an approximate hue [0..360]. */
function hexToHue(hex: string): number {
  const m = hex.replace('#', '')
  const r = parseInt(m.slice(0, 2), 16) / 255
  const g = parseInt(m.slice(2, 4), 16) / 255
  const b = parseInt(m.slice(4, 6), 16) / 255
  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  const d = max - min
  if (d === 0) return 0
  let h = 0
  if (max === r) h = ((g - b) / d) % 6
  else if (max === g) h = (b - r) / d + 2
  else h = (r - g) / d + 4
  h = Math.round(h * 60)
  return (h + 360) % 360
}

/* Approximate hue [0..360] -> hex for the color-picker swatch. */
function hueToHex(hue: number): string {
  const s = 0.85
  const l = 0.55
  const c = (1 - Math.abs(2 * l - 1)) * s
  const x = c * (1 - Math.abs(((hue / 60) % 2) - 1))
  const mm = l - c / 2
  let r = 0
  let g = 0
  let b = 0
  if (hue < 60) [r, g, b] = [c, x, 0]
  else if (hue < 120) [r, g, b] = [x, c, 0]
  else if (hue < 180) [r, g, b] = [0, c, x]
  else if (hue < 240) [r, g, b] = [0, x, c]
  else if (hue < 300) [r, g, b] = [x, 0, c]
  else [r, g, b] = [c, 0, x]
  const to = (v: number) =>
    Math.round((v + mm) * 255)
      .toString(16)
      .padStart(2, '0')
  return `#${to(r)}${to(g)}${to(b)}`
}

export function SettingsSection() {
  const { authed } = useSettings()
  return (
    <section className="mx-auto w-full max-w-2xl px-4 pb-32 pt-16 sm:pt-24">
      <ScrollReveal className="text-center">
        <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs uppercase tracking-widest text-primary">
          <Sparkles className="h-3.5 w-3.5" aria-hidden />
          Panel admin
        </span>
        <h1 className="font-heading text-4xl font-black tracking-tight text-balance sm:text-6xl">
          <span className="shimmer-text">Pengaturan</span>{' '}
          <span className="text-primary text-glow">website</span>
        </h1>
        <p className="mx-auto mt-4 max-w-md text-pretty leading-relaxed text-muted-foreground">
          Atur domain, kredensial Cloudflare, dan warna tema — semua berubah
          langsung di seluruh website.
        </p>
      </ScrollReveal>

      <div className="mt-10">{authed ? <Panels /> : <LoginForm />}</div>
    </section>
  )
}

function LoginForm() {
  const { login } = useSettings()
  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')
  const [remember, setRemember] = useState(true)
  const [show, setShow] = useState(false)
  const [err, setErr] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const ok = login(user, pass, remember)
    setErr(!ok)
  }

  return (
    <ScrollReveal>
      <form
        onSubmit={handleSubmit}
        className="box-glow relative mx-auto max-w-md overflow-hidden rounded-3xl border border-border bg-card/70 p-6 backdrop-blur-xl sm:p-8"
      >
        <span
          aria-hidden
          className="pointer-events-none absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-primary to-transparent opacity-70"
        />
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-primary/15 text-primary animate-float-slow">
          <Lock className="h-6 w-6" aria-hidden />
        </div>
        <h2 className="mt-4 text-center font-heading text-xl font-bold">
          Login diperlukan
        </h2>
        <p className="mt-1 text-center text-sm text-muted-foreground">
          Hanya admin yang bisa mengubah pengaturan.
        </p>

        <div className="mt-6 space-y-4">
          <div>
            <label
              htmlFor="user"
              className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
            >
              Username
            </label>
            <div className="flex items-center rounded-xl border border-input bg-background/60 px-3 transition-shadow focus-within:ring-2 focus-within:ring-ring">
              <User className="h-4 w-4 text-muted-foreground" aria-hidden />
              <input
                id="user"
                value={user}
                onChange={(e) => setUser(e.target.value)}
                autoComplete="username"
                placeholder="username"
                className="w-full bg-transparent px-2 py-3 text-sm outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="pass"
              className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
            >
              Password
            </label>
            <div className="flex items-center rounded-xl border border-input bg-background/60 pl-3 pr-1.5 transition-shadow focus-within:ring-2 focus-within:ring-ring">
              <KeyRound className="h-4 w-4 text-muted-foreground" aria-hidden />
              <input
                id="pass"
                type={show ? 'text' : 'password'}
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                autoComplete="current-password"
                placeholder="••••••••"
                className="w-full bg-transparent px-2 py-3 text-sm outline-none"
              />
              <EyeToggle revealed={show} onToggle={() => setShow((s) => !s)} />
            </div>
          </div>

          <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-border bg-background/40 px-4 py-3 transition-colors hover:border-primary/40">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="h-4 w-4 accent-[var(--primary)]"
            />
            <span className="text-sm">
              <span className="font-medium">Remember me</span>
              <span className="block text-xs text-muted-foreground">
                Tetap login, tak perlu masukkan user &amp; password lagi.
              </span>
            </span>
          </label>

          {err && (
            <p className="flex items-center gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
              <AlertCircle className="h-4 w-4 shrink-0" aria-hidden />
              Username atau password salah.
            </p>
          )}

          <Button type="submit" className="h-12 w-full rounded-xl font-heading">
            <Lock className="h-4 w-4" aria-hidden />
            Masuk
          </Button>
        </div>
      </form>
    </ScrollReveal>
  )
}

function Card({
  icon: Icon,
  title,
  desc,
  children,
}: {
  icon: typeof Globe
  title: string
  desc: string
  children: React.ReactNode
}) {
  return (
    <div className="group relative overflow-hidden rounded-3xl border border-border bg-card/70 p-6 backdrop-blur-xl transition-colors hover:border-primary/40">
      <span
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-primary/10 opacity-50 blur-3xl transition-opacity duration-500 group-hover:opacity-100"
      />
      <div className="relative flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15 text-primary">
          <Icon className="h-5 w-5" aria-hidden />
        </span>
        <div>
          <h3 className="font-heading text-base font-semibold">{title}</h3>
          <p className="text-xs text-muted-foreground">{desc}</p>
        </div>
      </div>
      <div className="relative mt-5">{children}</div>
    </div>
  )
}

function Panels() {
  const { domain, token, zoneId, hue, rgb, update, resetTheme, logout } =
    useSettings()

  const [domainDraft, setDomainDraft] = useState(domain)
  const [tokenDraft, setTokenDraft] = useState(token)
  const [zoneDraft, setZoneDraft] = useState(zoneId)
  const [showToken, setShowToken] = useState(false)
  const [savedKey, setSavedKey] = useState<string | null>(null)

  function flashSaved(key: string) {
    setSavedKey(key)
    setTimeout(() => setSavedKey((k) => (k === key ? null : k)), 1800)
  }

  function saveDomain() {
    const clean = domainDraft.trim().toLowerCase().replace(/^https?:\/\//, '')
    update({ domain: clean || DEFAULT_DOMAIN })
    flashSaved('domain')
  }

  function saveCloudflare() {
    update({ token: tokenDraft.trim(), zoneId: zoneDraft.trim() })
    flashSaved('cf')
  }

  return (
    <div className="space-y-6">
      {/* DOMAIN */}
      <ScrollReveal>
        <Card
          icon={Globe}
          title="Nama domain"
          desc="Ubah domain root yang dipakai di seluruh website."
        >
          <label
            htmlFor="domain"
            className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
          >
            Domain root
          </label>
          <div className="flex flex-col gap-3 sm:flex-row">
            <input
              id="domain"
              value={domainDraft}
              onChange={(e) => setDomainDraft(e.target.value)}
              placeholder="zulzz.my.id"
              className="w-full rounded-xl border border-input bg-background/60 px-4 py-3 font-mono text-sm outline-none focus:ring-2 focus:ring-ring"
            />
            <Button
              type="button"
              onClick={saveDomain}
              className="h-12 shrink-0 rounded-xl px-6"
            >
              {savedKey === 'domain' ? (
                <Check className="h-4 w-4" aria-hidden />
              ) : null}
              {savedKey === 'domain' ? 'Tersimpan' : 'Ubah semua'}
            </Button>
          </div>
          <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
            Contoh: ubah dari{' '}
            <span className="font-mono text-foreground">zulzz.my.id</span> ke{' '}
            <span className="font-mono text-foreground">zul.com</span>. Semua
            label subdomain, form, dan permintaan API langsung memakai domain
            baru ini.
          </p>
        </Card>
      </ScrollReveal>

      {/* CLOUDFLARE */}
      <ScrollReveal delay={80}>
        <Card
          icon={KeyRound}
          title="Kredensial Cloudflare"
          desc="Token API & Zone ID untuk mengelola DNS."
        >
          <div className="space-y-4">
            <div>
              <label
                htmlFor="zone"
                className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
              >
                Zone ID
              </label>
              <input
                id="zone"
                value={zoneDraft}
                onChange={(e) => setZoneDraft(e.target.value)}
                placeholder="(opsional) auto-detect dari domain"
                className="w-full rounded-xl border border-input bg-background/60 px-4 py-3 font-mono text-sm outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <div>
              <label
                htmlFor="token"
                className="mb-1.5 block font-mono text-xs uppercase tracking-widest text-muted-foreground"
              >
                API Token
              </label>
              <div className="flex items-center rounded-xl border border-input bg-background/60 pl-4 pr-1.5 focus-within:ring-2 focus-within:ring-ring">
                <input
                  id="token"
                  type={showToken ? 'text' : 'password'}
                  value={tokenDraft}
                  onChange={(e) => setTokenDraft(e.target.value)}
                  placeholder="(opsional) pakai token server default"
                  className="w-full bg-transparent py-3 font-mono text-sm outline-none"
                />
                <EyeToggle
                  revealed={showToken}
                  onToggle={() => setShowToken((s) => !s)}
                />
              </div>
            </div>

            <p className="flex items-start gap-2 rounded-xl border border-destructive/30 bg-destructive/10 px-3 py-2.5 text-xs leading-relaxed text-destructive">
              <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
              Token yang diisi di sini disimpan di browser. Kosongkan untuk
              memakai token server aman (CLOUDFLARE_API_TOKEN).
            </p>

            <Button
              type="button"
              onClick={saveCloudflare}
              className="h-12 w-full rounded-xl"
            >
              {savedKey === 'cf' ? (
                <Check className="h-4 w-4" aria-hidden />
              ) : null}
              {savedKey === 'cf' ? 'Tersimpan' : 'Simpan kredensial'}
            </Button>
          </div>
        </Card>
      </ScrollReveal>

      {/* THEME */}
      <ScrollReveal delay={160}>
        <Card
          icon={Palette}
          title="Tema warna"
          desc="Ubah warna brand dari ungu ke warna apa pun."
        >
          {/* live preview chip */}
          <div className="mb-5 flex items-center gap-3 rounded-2xl border border-border bg-background/40 p-3">
            <span
              className="h-12 w-12 shrink-0 rounded-xl ring-2 ring-border"
              style={{ backgroundColor: `oklch(0.6 0.27 ${hue})` }}
              aria-hidden
            />
            <div className="min-w-0">
              <p className="font-heading text-sm font-semibold">
                Warna brand aktif
              </p>
              <p className="font-mono text-xs text-muted-foreground">
                {rgb
                  ? 'Mode RGB (pelangi)'
                  : `hue ${Math.round(hue)}° · ${hueToHex(hue)}`}
              </p>
            </div>
          </div>

          {/* presets */}
          <div className="flex flex-wrap gap-2.5">
            {PRESETS.map((p) => {
              const isActive = !rgb && Math.abs(hue - p.hue) < 1
              return (
                <button
                  key={p.name}
                  type="button"
                  onClick={() => update({ hue: p.hue, rgb: false })}
                  title={p.name}
                  aria-label={`Warna ${p.name}`}
                  aria-pressed={isActive}
                  className={cn(
                    'h-10 w-10 rounded-full ring-2 ring-offset-2 ring-offset-card transition-transform hover:scale-110',
                    isActive ? 'ring-foreground' : 'ring-transparent',
                  )}
                  style={{ backgroundColor: `oklch(0.6 0.27 ${p.hue})` }}
                />
              )
            })}
          </div>

          {/* native RGB color picker */}
          <div className="mt-6 flex items-center justify-between gap-3 rounded-xl border border-border bg-background/40 px-4 py-3">
            <span className="flex items-center gap-2 text-sm">
              <Pipette className="h-4 w-4 text-primary" aria-hidden />
              <span>
                <span className="block font-medium">Pemilih warna (RGB)</span>
                <span className="block text-xs text-muted-foreground">
                  Pilih warna persis sesukamu.
                </span>
              </span>
            </span>
            <input
              type="color"
              aria-label="Pilih warna brand"
              value={hueToHex(hue)}
              disabled={rgb}
              onChange={(e) =>
                update({ hue: hexToHue(e.target.value), rgb: false })
              }
              className="h-11 w-16 cursor-pointer rounded-lg border border-border bg-transparent disabled:opacity-50"
            />
          </div>

          {/* hue slider */}
          <div className="mt-6">
            <div className="mb-2 flex items-center justify-between">
              <label
                htmlFor="hue"
                className="font-mono text-xs uppercase tracking-widest text-muted-foreground"
              >
                Hue kustom
              </label>
              <span className="font-mono text-xs text-primary">
                {rgb ? 'RGB' : `${Math.round(hue)}°`}
              </span>
            </div>
            <input
              id="hue"
              type="range"
              min={0}
              max={360}
              value={hue}
              disabled={rgb}
              onChange={(e) =>
                update({ hue: Number(e.target.value), rgb: false })
              }
              className="h-3 w-full cursor-pointer appearance-none rounded-full disabled:opacity-50"
              style={{
                background:
                  'linear-gradient(to right, oklch(0.6 0.27 0), oklch(0.6 0.27 60), oklch(0.6 0.27 120), oklch(0.6 0.27 180), oklch(0.6 0.27 240), oklch(0.6 0.27 300), oklch(0.6 0.27 360))',
              }}
            />
          </div>

          {/* RGB rainbow mode toggle */}
          <button
            type="button"
            onClick={() => update({ rgb: !rgb })}
            className="mt-5 flex w-full items-center justify-between rounded-xl border border-border bg-background/40 px-4 py-3 text-left transition-colors hover:bg-background/70"
          >
            <span>
              <span className="block text-sm font-medium">Mode RGB pelangi</span>
              <span className="block text-xs text-muted-foreground">
                Warna berputar otomatis seperti pelangi.
              </span>
            </span>
            <span
              className={cn(
                'relative h-6 w-11 rounded-full transition-colors',
                rgb ? 'bg-primary' : 'bg-muted',
              )}
            >
              <span
                className={cn(
                  'absolute top-0.5 h-5 w-5 rounded-full bg-background transition-all',
                  rgb ? 'left-[22px]' : 'left-0.5',
                )}
              />
            </span>
          </button>

          <button
            type="button"
            onClick={resetTheme}
            className="mt-4 inline-flex items-center gap-2 text-xs font-medium text-muted-foreground transition-colors hover:text-primary"
          >
            <RotateCcw className="h-3.5 w-3.5" aria-hidden />
            Kembali ke ungu default
          </button>
        </Card>
      </ScrollReveal>

      {/* LOGOUT */}
      <ScrollReveal delay={220}>
        <Button
          type="button"
          variant="secondary"
          onClick={logout}
          className="h-12 w-full rounded-xl"
        >
          <LogOut className="h-4 w-4" aria-hidden />
          Keluar
        </Button>
      </ScrollReveal>
    </div>
  )
}
